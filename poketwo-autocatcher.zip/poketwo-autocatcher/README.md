# Pokétwo AutoCatcher

A professional-grade Pokétwo AutoCatcher bot with advanced features for catching, leveling, and market operations.

## Features

### ✅ Setup & Control
- Fully interactive setup process (no coding knowledge required)
- Post-setup reconfiguration through commands
- Bot only operates where specifically enabled (non-global / non-intrusive)

### 🎯 AutoCatch System
- Catches all Pokémon reliably
- Quest completion automation
- Shiny hunting support
- Dex completion tracking and reward claiming
- Custom catch filters (include by name, type, rarity, etc.)
- Incense Sniper: reacts in less than 1 second
- Support for custom/random delays to avoid detection

### 🔁 Auto-Leveler & Spawner
- Level-up Pokémon based on user-defined PokéID queue
- Custom evolution options and target level selection
- Fast spawner
- Unique spammer mode
- Special spammer
- Multiple supported modes (manual, cycle, scheduled)

### 📝 Logger & Notification System
- Real-time spawn notifications
- Alerts for rare spawns (mythical, shiny, legendary)
- Detailed catch logs (Pokémon name, level, type, rarity, evolution status, etc.)

### 💹 Market Throne System
- Market Sniper: fastest on the market, with custom filters and price targeting
- Market Flipper: flips Pokémon pricing quickly with intuitive interface
- Market Swiper: dumps trash Pokémon from a user-defined list at a chosen price range
- SPY Stock Prediction Engine: predicts market price fluctuations and helps control trade strategy

### 👑 Additional Features
- Lightweight and optimized backend
- Professionally styled UI (premium-quality look and experience)
- Support for Generation 9 Pokémon
- Automatic captcha solving

## Installation

### Prerequisites
- Node.js v16 or higher
- MongoDB (optional, for advanced features)
- Discord Bot Token

### Setup
1. Clone the repository:
   ```
   git clone https://github.com/yourusername/poketwo-autocatcher.git
   cd poketwo-autocatcher
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Create a `.env` file with the following content:
   ```
   DISCORD_TOKEN=your_discord_bot_token
   PREFIX=p!
   MONGODB_URI=mongodb://localhost:27017/poketwo-autocatcher
   WEB_PORT=3000
   WEB_ENABLED=true
   ```

4. Start the bot:
   ```
   npm start
   ```

## Usage

### Bot Commands
- `p!help` - Shows help information
- `p!enable` - Enable the bot in the current server
- `p!disable` - Disable the bot in the current server
- `p!autocatcher <enable|disable|status|filter>` - Control the AutoCatcher
- `p!autoleveler <enable|disable|status|add|remove>` - Control the Auto-Leveler
- `p!spawner <enable|disable|status|mode>` - Control the Spawner
- `p!market <sniper|flipper|swiper> <enable|disable|status>` - Control the Market features

### Web Dashboard
The web dashboard is available at `http://localhost:3000` (or the port you specified in the `.env` file).

## Anti-Detection Features
- Human-like typing simulation
- Randomized command execution
- Activity pattern simulation
- Message content randomization
- Pattern recognition avoidance

## Disclaimer
This bot is for educational purposes only. Use at your own risk. The developers are not responsible for any consequences resulting from the use of this bot.

## License
MIT License