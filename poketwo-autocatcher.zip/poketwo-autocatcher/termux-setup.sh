#!/data/data/com.termux/files/usr/bin/bash

# Termux setup script for Pokétwo AutoCatcher

echo "Pokétwo AutoCatcher - Termux Setup"
echo "=================================="
echo

# Update package lists
echo "[1/7] Updating package lists..."
pkg update -y

# Install required packages
echo "[2/7] Installing required packages..."
pkg install -y nodejs git python

# Clone the repository if not already cloned
if [ ! -d "poketwo-autocatcher" ]; then
    echo "[3/7] Cloning repository..."
    git clone https://github.com/yourusername/poketwo-autocatcher.git
    cd poketwo-autocatcher
else
    echo "[3/7] Repository already exists, updating..."
    cd poketwo-autocatcher
    git pull
fi

# Install dependencies
echo "[4/7] Installing Node.js dependencies..."
npm install

# Create necessary directories
echo "[5/7] Creating necessary directories..."
mkdir -p data/cache
mkdir -p logs

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "[6/7] Setting up configuration..."
    echo "Please enter your Discord bot token:"
    read -r token
    
    echo "DISCORD_TOKEN=$token" > .env
    echo "PREFIX=p!" >> .env
    echo "WEB_ENABLED=true" >> .env
    echo "WEB_PORT=3000" >> .env
    echo "NODE_ENV=production" >> .env
    
    echo "Configuration saved to .env file."
else
    echo "[6/7] Configuration already exists."
fi

# Create start script
echo "[7/7] Creating start script..."
cat > start-termux.sh << 'EOL'
#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
node src/index.js
EOL

chmod +x start-termux.sh

echo
echo "Setup complete! To start the bot, run:"
echo "./start-termux.sh"
echo
echo "To keep the bot running after closing Termux, use:"
echo "nohup ./start-termux.sh > logs/bot.log 2>&1 &"