# Installation Guide

This guide will help you set up the Pokétwo AutoCatcher bot on different platforms.

## Prerequisites

- Discord Bot Token (create one at [Discord Developer Portal](https://discord.com/developers/applications))
- Node.js v16 or higher
- Basic knowledge of command line

## Windows Installation

1. **Install Node.js**
   - Download and install Node.js from [nodejs.org](https://nodejs.org/)
   - Make sure to select the option to install npm during installation

2. **Download the Bot**
   - Download the latest release from GitHub
   - Extract the ZIP file to a folder of your choice

3. **Configure the Bot**
   - Open the extracted folder
   - Copy `.env.example` to `.env`
   - Edit the `.env` file with your Discord bot token and other settings

4. **Install Dependencies**
   - Open Command Prompt (cmd)
   - Navigate to the bot folder using `cd path\to\poketwo-autocatcher`
   - Run `npm install`

5. **Start the Bot**
   - Run `npm start` or `node src/index.js`

## Linux/macOS Installation

1. **Install Node.js**
   ```bash
   # Ubuntu/Debian
   curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
   sudo apt-get install -y nodejs

   # macOS (using Homebrew)
   brew install node
   ```

2. **Download and Configure the Bot**
   ```bash
   # Clone the repository
   git clone https://github.com/yourusername/poketwo-autocatcher.git
   cd poketwo-autocatcher

   # Configure the bot
   cp .env.example .env
   nano .env  # Edit with your Discord bot token
   ```

3. **Install Dependencies and Start**
   ```bash
   npm install
   chmod +x start.sh
   ./start.sh
   ```

## Termux (Android) Installation

1. **Install Termux**
   - Download Termux from [F-Droid](https://f-droid.org/en/packages/com.termux/)
   - Open Termux and wait for the initial setup to complete

2. **Run the Setup Script**
   ```bash
   # Install curl
   pkg install curl -y

   # Download and run the setup script
   curl -sL https://raw.githubusercontent.com/yourusername/poketwo-autocatcher/main/termux-setup.sh -o setup.sh
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Start the Bot**
   ```bash
   cd poketwo-autocatcher
   ./start-termux.sh
   ```

4. **Keep the Bot Running in Background**
   ```bash
   nohup ./start-termux.sh > logs/bot.log 2>&1 &
   ```

## Docker Installation

1. **Install Docker**
   - Follow the instructions at [docker.com](https://docs.docker.com/get-docker/)

2. **Pull and Run the Docker Image**
   ```bash
   # Create a directory for configuration
   mkdir -p poketwo-config
   cd poketwo-config

   # Create .env file
   echo "DISCORD_TOKEN=your_token_here" > .env
   echo "PREFIX=p!" >> .env
   echo "WEB_ENABLED=true" >> .env
   echo "WEB_PORT=3000" >> .env

   # Run the Docker container
   docker run -d \
     --name poketwo-autocatcher \
     -p 3000:3000 \
     --restart unless-stopped \
     -v $(pwd)/.env:/app/.env \
     -v poketwo-data:/app/data \
     yourusername/poketwo-autocatcher:latest
   ```

## Troubleshooting

### Bot Won't Start
- Check if your Discord token is correct
- Ensure Node.js is installed correctly (run `node -v` to check)
- Check if all dependencies are installed (run `npm install` again)

### Bot Starts but Doesn't Respond
- Make sure your bot has the necessary permissions in Discord
- Check if the bot is enabled in the server (`p!enable`)
- Verify that the bot can see the channels where Pokétwo spawns

### Web Dashboard Not Working
- Check if `WEB_ENABLED=true` in your `.env` file
- Make sure the port specified in `WEB_PORT` is not being used by another application
- Try accessing the dashboard at `http://localhost:3000` (or the port you specified)

## Updating the Bot

### Manual Update
```bash
# Navigate to the bot directory
cd path/to/poketwo-autocatcher

# Pull the latest changes
git pull

# Install any new dependencies
npm install

# Restart the bot
./start.sh
```

### Docker Update
```bash
# Pull the latest image
docker pull yourusername/poketwo-autocatcher:latest

# Stop and remove the old container
docker stop poketwo-autocatcher
docker rm poketwo-autocatcher

# Run a new container with the updated image
docker run -d \
  --name poketwo-autocatcher \
  -p 3000:3000 \
  --restart unless-stopped \
  -v $(pwd)/.env:/app/.env \
  -v poketwo-data:/app/data \
  yourusername/poketwo-autocatcher:latest
```