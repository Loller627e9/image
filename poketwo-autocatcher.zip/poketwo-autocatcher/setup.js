/**
 * Pokétwo AutoCatcher Setup Script
 * 
 * This script guides the user through the initial setup process.
 */

const readline = require('readline');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// ANSI color codes
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  blink: '\x1b[5m',
  reverse: '\x1b[7m',
  hidden: '\x1b[8m',
  
  fg: {
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    crimson: '\x1b[38m'
  },
  
  bg: {
    black: '\x1b[40m',
    red: '\x1b[41m',
    green: '\x1b[42m',
    yellow: '\x1b[43m',
    blue: '\x1b[44m',
    magenta: '\x1b[45m',
    cyan: '\x1b[46m',
    white: '\x1b[47m',
    crimson: '\x1b[48m'
  }
};

// Configuration object
const config = {
  discord: {
    token: '',
    prefix: 'p!'
  },
  database: {
    enabled: false,
    uri: 'mongodb://localhost:27017/poketwo-autocatcher'
  },
  web: {
    enabled: true,
    port: 3000
  },
  features: {
    autocatcher: true,
    autoleveler: true,
    spawner: true,
    market: true,
    captchaSolver: true
  }
};

// Display welcome message
function displayWelcome() {
  console.clear();
  console.log(`${colors.fg.red}${colors.bright}
  ╔═══════════════════════════════════════════════════════════╗
  ║                                                           ║
  ║   ${colors.fg.white}Pokétwo AutoCatcher${colors.fg.red} - ${colors.fg.yellow}Setup Wizard${colors.fg.red}                   ║
  ║                                                           ║
  ║   ${colors.fg.cyan}A professional-grade Pokétwo automation tool${colors.fg.red}           ║
  ║                                                           ║
  ╚═══════════════════════════════════════════════════════════╝
  ${colors.reset}`);
  
  console.log(`${colors.fg.cyan}This wizard will guide you through the initial setup process.${colors.reset}\n`);
  console.log(`${colors.fg.yellow}Please answer the following questions to configure your bot:${colors.reset}\n`);
}

// Ask for Discord token
function askDiscordToken() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.green}Enter your Discord bot token: ${colors.reset}`, (token) => {
      if (!token) {
        console.log(`${colors.fg.red}Token cannot be empty. Please try again.${colors.reset}\n`);
        return askDiscordToken().then(resolve);
      }
      
      config.discord.token = token;
      resolve();
    });
  });
}

// Ask for bot prefix
function askBotPrefix() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.green}Enter your preferred bot prefix (default: p!): ${colors.reset}`, (prefix) => {
      if (prefix) {
        config.discord.prefix = prefix;
      }
      resolve();
    });
  });
}

// Ask for database configuration
function askDatabaseConfig() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.green}Do you want to use MongoDB for advanced features? (y/n, default: n): ${colors.reset}`, (answer) => {
      config.database.enabled = answer.toLowerCase() === 'y';
      
      if (config.database.enabled) {
        rl.question(`${colors.fg.green}Enter MongoDB URI (default: mongodb://localhost:27017/poketwo-autocatcher): ${colors.reset}`, (uri) => {
          if (uri) {
            config.database.uri = uri;
          }
          resolve();
        });
      } else {
        resolve();
      }
    });
  });
}

// Ask for web dashboard configuration
function askWebConfig() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.green}Do you want to enable the web dashboard? (y/n, default: y): ${colors.reset}`, (answer) => {
      if (answer.toLowerCase() === 'n') {
        config.web.enabled = false;
        resolve();
      } else {
        config.web.enabled = true;
        
        rl.question(`${colors.fg.green}Enter web dashboard port (default: 3000): ${colors.reset}`, (port) => {
          if (port && !isNaN(parseInt(port))) {
            config.web.port = parseInt(port);
          }
          resolve();
        });
      }
    });
  });
}

// Ask for feature configuration
function askFeatureConfig() {
  return new Promise((resolve) => {
    console.log(`\n${colors.fg.yellow}Feature Configuration:${colors.reset}\n`);
    
    const askFeature = (feature, description, defaultValue, callback) => {
      rl.question(`${colors.fg.green}Enable ${description}? (y/n, default: ${defaultValue ? 'y' : 'n'}): ${colors.reset}`, (answer) => {
        if (answer.toLowerCase() === 'n') {
          config.features[feature] = false;
        } else if (answer.toLowerCase() === 'y') {
          config.features[feature] = true;
        } else {
          config.features[feature] = defaultValue;
        }
        callback();
      });
    };
    
    askFeature('autocatcher', 'AutoCatcher (automatic Pokémon catching)', true, () => {
      askFeature('autoleveler', 'Auto-Leveler (automatic Pokémon leveling)', true, () => {
        askFeature('spawner', 'Spawner (automatic Pokémon spawning)', true, () => {
          askFeature('market', 'Market Throne (market sniping and automation)', true, () => {
            askFeature('captchaSolver', 'Captcha Solver (automatic captcha solving)', true, () => {
              resolve();
            });
          });
        });
      });
    });
  });
}

// Create .env file
function createEnvFile() {
  return new Promise((resolve) => {
    const envContent = `# Discord Bot Configuration
DISCORD_TOKEN=${config.discord.token}
PREFIX=${config.discord.prefix}

# Database Configuration
DB_ENABLED=${config.database.enabled}
MONGODB_URI=${config.database.uri}

# Web Dashboard Configuration
WEB_ENABLED=${config.web.enabled}
WEB_PORT=${config.web.port}

# Feature Configuration
AUTOCATCHER_ENABLED=${config.features.autocatcher}
AUTOLEVELER_ENABLED=${config.features.autoleveler}
SPAWNER_ENABLED=${config.features.spawner}
MARKET_ENABLED=${config.features.market}
CAPTCHA_SOLVER_ENABLED=${config.features.captchaSolver}

# Environment
NODE_ENV=production`;
    
    fs.writeFileSync(path.join(__dirname, '.env'), envContent);
    resolve();
  });
}

// Create necessary directories
function createDirectories() {
  return new Promise((resolve) => {
    const directories = [
      'data',
      'data/cache',
      'logs'
    ];
    
    directories.forEach(dir => {
      const dirPath = path.join(__dirname, dir);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
    });
    
    resolve();
  });
}

// Install dependencies
function installDependencies() {
  return new Promise((resolve) => {
    console.log(`\n${colors.fg.yellow}Installing dependencies...${colors.reset}\n`);
    
    try {
      execSync('npm install', { stdio: 'inherit' });
      resolve();
    } catch (error) {
      console.error(`${colors.fg.red}Error installing dependencies:${colors.reset}`, error);
      resolve();
    }
  });
}

// Display completion message
function displayCompletion() {
  console.clear();
  console.log(`${colors.fg.green}${colors.bright}
  ╔═══════════════════════════════════════════════════════════╗
  ║                                                           ║
  ║   ${colors.fg.white}Pokétwo AutoCatcher${colors.fg.green} - ${colors.fg.yellow}Setup Complete!${colors.fg.green}                 ║
  ║                                                           ║
  ╚═══════════════════════════════════════════════════════════╝
  ${colors.reset}`);
  
  console.log(`${colors.fg.cyan}Your bot has been successfully configured!${colors.reset}\n`);
  console.log(`${colors.fg.yellow}Configuration Summary:${colors.reset}`);
  console.log(`${colors.fg.white}• Bot Prefix: ${colors.fg.cyan}${config.discord.prefix}${colors.reset}`);
  console.log(`${colors.fg.white}• Database: ${config.database.enabled ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  console.log(`${colors.fg.white}• Web Dashboard: ${config.web.enabled ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  if (config.web.enabled) {
    console.log(`${colors.fg.white}  - Port: ${colors.fg.cyan}${config.web.port}${colors.reset}`);
  }
  console.log(`${colors.fg.white}• Features:${colors.reset}`);
  console.log(`${colors.fg.white}  - AutoCatcher: ${config.features.autocatcher ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  console.log(`${colors.fg.white}  - Auto-Leveler: ${config.features.autoleveler ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  console.log(`${colors.fg.white}  - Spawner: ${config.features.spawner ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  console.log(`${colors.fg.white}  - Market Throne: ${config.features.market ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  console.log(`${colors.fg.white}  - Captcha Solver: ${config.features.captchaSolver ? colors.fg.green + 'Enabled' : colors.fg.red + 'Disabled'}${colors.reset}`);
  
  console.log(`\n${colors.fg.yellow}To start the bot, run:${colors.reset}`);
  console.log(`${colors.fg.white}npm start${colors.reset}`);
  console.log(`${colors.fg.white}or${colors.reset}`);
  console.log(`${colors.fg.white}node src/index.js${colors.reset}`);
  
  if (config.web.enabled) {
    console.log(`\n${colors.fg.yellow}Web dashboard will be available at:${colors.reset}`);
    console.log(`${colors.fg.white}http://localhost:${config.web.port}${colors.reset}`);
  }
  
  console.log(`\n${colors.fg.green}Thank you for using Pokétwo AutoCatcher!${colors.reset}\n`);
}

// Main setup function
async function setup() {
  displayWelcome();
  
  await askDiscordToken();
  await askBotPrefix();
  await askDatabaseConfig();
  await askWebConfig();
  await askFeatureConfig();
  
  console.log(`\n${colors.fg.yellow}Creating configuration files...${colors.reset}`);
  await createEnvFile();
  
  console.log(`${colors.fg.yellow}Creating necessary directories...${colors.reset}`);
  await createDirectories();
  
  await installDependencies();
  
  displayCompletion();
  
  rl.close();
}

// Run setup
setup();