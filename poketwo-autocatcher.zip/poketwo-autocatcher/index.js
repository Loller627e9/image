require('dotenv').config();
const { Client, Intents } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { loadConfig } = require('./src/core/config');
const { setupCommands } = require('./src/core/commands');
const { setupEvents } = require('./src/core/events');
const { initializeDatabase } = require('./src/core/database');
const { startWebServer } = require('./src/ui/web/server');
const { logger } = require('./src/modules/logger/logger');

// Check if .env file exists, if not create it with template
if (!fs.existsSync('.env')) {
  fs.writeFileSync('.env', 'DISCORD_TOKEN=\nPREFIX=p!\nMONGODB_URI=mongodb://localhost:27017/poketwo-autocatcher\nWEB_PORT=3000\n');
  logger.warn('Created .env file. Please fill in your Discord token and other settings.');
  process.exit(0);
}

// Initialize the Discord client with required intents
const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
    Intents.FLAGS.DIRECT_MESSAGES,
    Intents.FLAGS.MESSAGE_CONTENT
  ],
  partials: ['MESSAGE', 'CHANNEL', 'REACTION']
});

// Global bot configuration
global.botConfig = {
  prefix: process.env.PREFIX || 'p!',
  version: require('./package.json').version,
  startTime: Date.now(),
  enabledServers: new Set(),
  catchQueue: [],
  levelQueue: [],
  marketQueue: []
};

// Initialize components
async function initialize() {
  try {
    // Load user configuration
    await loadConfig();
    
    // Setup command and event handlers
    setupCommands(client);
    setupEvents(client);
    
    // Initialize database connection
    await initializeDatabase();
    
    // Start web dashboard if enabled
    if (process.env.WEB_ENABLED === 'true') {
      startWebServer();
    }
    
    // Login to Discord
    await client.login(process.env.DISCORD_TOKEN);
    
    logger.success(`Bot initialized successfully! Logged in as ${client.user.tag}`);
  } catch (error) {
    logger.error('Failed to initialize the bot:', error);
    process.exit(1);
  }
}

// Handle process termination
process.on('SIGINT', () => {
  logger.info('Shutting down...');
  client.destroy();
  process.exit(0);
});

// Start the bot
initialize();