/**
 * Pokétwo AutoCatcher - Main Entry Point
 * 
 * A professional-grade Pokétwo automation tool with advanced features
 * for catching, leveling, and market operations.
 */

// Import required modules
require('dotenv').config();
const { Client, Intents } = require('discord.js');
const { logger } = require('./modules/logger/logger');
const { loadCommands } = require('./core/commands');
const { loadEvents } = require('./core/events');
const { connectDatabase } = require('./core/database');
const { loadConfig } = require('./core/config');
const { startWebServer } = require('./ui/web/server');

// Initialize global configuration
global.botConfig = {
  prefix: process.env.PREFIX || 'p!',
  version: '1.0.0',
  startTime: Date.now(),
  enabledServers: new Set(),
  catchQueue: [],
  levelQueue: [],
  marketQueue: [],
  userConfig: null
};

// Create Discord client with required intents
const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
    Intents.FLAGS.DIRECT_MESSAGES
  ],
  partials: ['MESSAGE', 'CHANNEL', 'REACTION']
});

// Store client in global config
global.client = client;

// Display startup banner
function displayBanner() {
  console.log(`
  ╔═══════════════════════════════════════════════════════════╗
  ║                                                           ║
  ║   Pokétwo AutoCatcher v${global.botConfig.version}                            ║
  ║                                                           ║
  ║   A professional-grade Pokétwo automation tool            ║
  ║                                                           ║
  ╚═══════════════════════════════════════════════════════════╝
  `);
}

// Initialize the bot
async function init() {
  try {
    displayBanner();
    
    // Load configuration
    logger.info('Loading configuration...');
    await loadConfig();
    
    // Connect to database if enabled
    if (process.env.DB_ENABLED === 'true') {
      logger.info('Connecting to database...');
      await connectDatabase();
    }
    
    // Load commands
    logger.info('Loading commands...');
    await loadCommands(client);
    
    // Load events
    logger.info('Loading events...');
    await loadEvents(client);
    
    // Start web server if enabled
    if (process.env.WEB_ENABLED === 'true') {
      logger.info('Starting web server...');
      await startWebServer();
    }
    
    // Login to Discord
    logger.info('Logging in to Discord...');
    await client.login(process.env.DISCORD_TOKEN);
  } catch (error) {
    logger.error('Error during initialization:', error);
    process.exit(1);
  }
}

// Handle process events
process.on('unhandledRejection', error => {
  logger.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
  logger.error('Uncaught exception:', error);
});

process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down...');
  client.destroy();
  process.exit(0);
});

// Start the bot
init();