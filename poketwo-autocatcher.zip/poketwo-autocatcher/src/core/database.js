const mongoose = require('mongoose');
const { logger } = require('../modules/logger/logger');

// Initialize database connection
async function initializeDatabase() {
  try {
    // Check if MongoDB URI is provided
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/poketwo-autocatcher';
    
    // Connect to MongoDB
    await mongoose.connect(mongoUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    logger.info('Connected to MongoDB database');
    return true;
  } catch (error) {
    logger.error('Failed to connect to MongoDB:', error);
    logger.warn('Running without database. Some features may be limited.');
    return false;
  }
}

// Pokemon schema
const pokemonSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  dexNumber: { type: Number, required: true, index: true },
  types: [{ type: String }],
  rarity: { type: String, enum: ['common', 'uncommon', 'rare', 'legendary', 'mythical'], default: 'common' },
  generation: { type: Number },
  baseStats: {
    hp: Number,
    attack: Number,
    defense: Number,
    spAttack: Number,
    spDefense: Number,
    speed: Number
  },
  evolutions: [{
    name: String,
    level: Number,
    method: String
  }],
  imageUrl: String,
  description: String
});

// Catch log schema
const catchLogSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  pokemonName: { type: String, required: true },
  level: { type: Number },
  iv: { type: Number },
  timestamp: { type: Date, default: Date.now },
  shiny: { type: Boolean, default: false },
  channelId: String,
  guildId: String
});

// Market log schema
const marketLogSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  action: { type: String, enum: ['buy', 'sell', 'list'], required: true },
  pokemonName: { type: String, required: true },
  price: { type: Number, required: true },
  level: { type: Number },
  iv: { type: Number },
  timestamp: { type: Date, default: Date.now },
  profit: { type: Number },
  shiny: { type: Boolean, default: false }
});

// Server settings schema
const serverSettingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  allowedChannels: [{ type: String }],
  allowedUsers: [{ type: String }],
  prefix: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Create models
const Pokemon = mongoose.models.Pokemon || mongoose.model('Pokemon', pokemonSchema);
const CatchLog = mongoose.models.CatchLog || mongoose.model('CatchLog', catchLogSchema);
const MarketLog = mongoose.models.MarketLog || mongoose.model('MarketLog', marketLogSchema);
const ServerSettings = mongoose.models.ServerSettings || mongoose.model('ServerSettings', serverSettingsSchema);

module.exports = {
  initializeDatabase,
  models: {
    Pokemon,
    CatchLog,
    MarketLog,
    ServerSettings
  }
};