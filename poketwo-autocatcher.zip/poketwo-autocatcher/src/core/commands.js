const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const { logger } = require('../modules/logger/logger');

// Command collection
const commands = new Collection();

// Setup commands
function setupCommands(client) {
  client.commands = commands;
  
  // Load command modules
  loadCommandsFromDirectory(path.join(__dirname, '../modules'));
  
  logger.info(`Loaded ${commands.size} commands`);
}

// Load commands from directory recursively
function loadCommandsFromDirectory(directory) {
  const items = fs.readdirSync(directory, { withFileTypes: true });
  
  for (const item of items) {
    const itemPath = path.join(directory, item.name);
    
    if (item.isDirectory()) {
      // Recursively load commands from subdirectories
      loadCommandsFromDirectory(itemPath);
    } else if (item.name.endsWith('Command.js')) {
      try {
        // Load command module
        const command = require(itemPath);
        
        // Register command
        if (command.name && command.execute) {
          commands.set(command.name, command);
          logger.debug(`Loaded command: ${command.name}`);
          
          // Register aliases if any
          if (command.aliases && Array.isArray(command.aliases)) {
            command.aliases.forEach(alias => {
              commands.set(alias, command);
            });
          }
        } else {
          logger.warn(`Invalid command module: ${itemPath}`);
        }
      } catch (error) {
        logger.error(`Failed to load command: ${itemPath}`, error);
      }
    }
  }
}

// Handle command execution
async function handleCommand(message, prefix) {
  // Ignore messages that don't start with the prefix or are from bots
  if (!message.content.startsWith(prefix) || message.author.bot) return;
  
  // Parse command and arguments
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  
  // Find command
  const command = commands.get(commandName);
  if (!command) return;
  
  // Check if command is server-only and if it's enabled in this server
  if (command.serverOnly && message.channel.type === 'DM') {
    return message.reply('This command can only be used in a server.');
  }
  
  // Check if command is enabled in this server
  if (command.serverOnly && !global.botConfig.enabledServers.has(message.guild.id)) {
    return message.reply('The bot is not enabled in this server. Use `' + prefix + 'enable` to enable it.');
  }
  
  // Check if user has required permissions
  if (command.permissions && message.channel.type !== 'DM') {
    const authorPerms = message.channel.permissionsFor(message.author);
    if (!authorPerms || !command.permissions.every(perm => authorPerms.has(perm))) {
      return message.reply('You do not have the required permissions to use this command.');
    }
  }
  
  // Check if command requires arguments
  if (command.args && !args.length) {
    let reply = 'You didn\'t provide any arguments.';
    
    if (command.usage) {
      reply += `\nUsage: \`${prefix}${command.name} ${command.usage}\``;
    }
    
    return message.reply(reply);
  }
  
  // Execute command
  try {
    await command.execute(message, args);
  } catch (error) {
    logger.error(`Command execution error: ${command.name}`, error);
    message.reply('There was an error executing that command.');
  }
}

module.exports = {
  setupCommands,
  handleCommand,
  commands
};