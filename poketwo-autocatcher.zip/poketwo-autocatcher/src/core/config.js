const fs = require('fs');
const path = require('path');
const { logger } = require('../modules/logger/logger');

// Default configuration
const defaultConfig = {
  // AutoCatcher settings
  autocatcher: {
    enabled: true,
    delay: {
      min: 1000,
      max: 3000,
      randomize: true
    },
    filters: {
      enabled: false,
      includeNames: [],
      excludeNames: [],
      includeTypes: [],
      excludeTypes: [],
      includeRarity: ['common', 'uncommon', 'rare', 'legendary', 'mythical'],
      minIV: 0
    },
    shinyHunting: {
      enabled: false,
      targetPokemon: []
    },
    questCompletion: {
      enabled: true,
      autoClaimRewards: true
    },
    dexCompletion: {
      enabled: true,
      autoClaimRewards: true
    },
    incenseSniper: {
      enabled: true,
      reactionDelay: 800
    }
  },
  
  // Auto-Leveler settings
  autoleveler: {
    enabled: false,
    queue: [],
    targetLevel: 100,
    evolution: {
      enabled: true,
      skipEvolutions: []
    },
    mode: 'manual' // manual, cycle, scheduled
  },
  
  // Spawner settings
  spawner: {
    enabled: false,
    mode: 'normal', // normal, spam, special
    interval: 15000,
    channels: []
  },
  
  // Logger settings
  logger: {
    enabled: true,
    logToFile: true,
    logToConsole: true,
    logLevel: 'info',
    notifications: {
      rare: true,
      shiny: true,
      legendary: true,
      mythical: true,
      highIV: true,
      highIVThreshold: 80
    }
  },
  
  // Market settings
  market: {
    sniper: {
      enabled: false,
      maxPrice: 10000,
      targetPokemon: [],
      refreshInterval: 5000
    },
    flipper: {
      enabled: false,
      minProfit: 1000,
      maxHoldTime: 86400000 // 24 hours
    },
    swiper: {
      enabled: false,
      trashPokemon: [],
      priceRange: {
        min: 10,
        max: 100
      }
    },
    spy: {
      enabled: false,
      trackPokemon: []
    }
  },
  
  // Anti-detection settings
  antiDetection: {
    enabled: true,
    humanLikeTyping: true,
    randomizeCommands: true,
    activitySimulation: true,
    typingSpeed: {
      min: 50,
      max: 150
    }
  },
  
  // Captcha solver settings
  captchaSolver: {
    enabled: true,
    method: 'local', // local, api
    apiKey: '',
    apiEndpoint: ''
  }
};

// User configuration path
const configPath = path.join(__dirname, '../../data/config.json');

// Load configuration
async function loadConfig() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(__dirname, '../../data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Check if config file exists
    if (!fs.existsSync(configPath)) {
      // Create default config file
      fs.writeFileSync(configPath, JSON.stringify(defaultConfig, null, 2));
      logger.info('Created default configuration file');
      return defaultConfig;
    }
    
    // Read and parse config file
    const configData = fs.readFileSync(configPath, 'utf8');
    const config = JSON.parse(configData);
    
    // Merge with default config to ensure all properties exist
    const mergedConfig = mergeConfigs(defaultConfig, config);
    
    // Update global config
    global.botConfig.userConfig = mergedConfig;
    
    logger.info('Configuration loaded successfully');
    return mergedConfig;
  } catch (error) {
    logger.error('Failed to load configuration:', error);
    // Fallback to default config
    global.botConfig.userConfig = defaultConfig;
    return defaultConfig;
  }
}

// Save configuration
async function saveConfig(config) {
  try {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    global.botConfig.userConfig = config;
    logger.info('Configuration saved successfully');
    return true;
  } catch (error) {
    logger.error('Failed to save configuration:', error);
    return false;
  }
}

// Update specific configuration section
async function updateConfig(section, key, value) {
  try {
    const config = global.botConfig.userConfig || await loadConfig();
    
    if (!config[section]) {
      logger.error(`Configuration section '${section}' does not exist`);
      return false;
    }
    
    if (key) {
      config[section][key] = value;
    } else {
      config[section] = value;
    }
    
    return await saveConfig(config);
  } catch (error) {
    logger.error('Failed to update configuration:', error);
    return false;
  }
}

// Helper function to merge configs
function mergeConfigs(defaultConfig, userConfig) {
  const merged = {};
  
  for (const key in defaultConfig) {
    if (typeof defaultConfig[key] === 'object' && !Array.isArray(defaultConfig[key])) {
      merged[key] = mergeConfigs(defaultConfig[key], userConfig[key] || {});
    } else {
      merged[key] = userConfig[key] !== undefined ? userConfig[key] : defaultConfig[key];
    }
  }
  
  return merged;
}

module.exports = {
  loadConfig,
  saveConfig,
  updateConfig,
  defaultConfig
};