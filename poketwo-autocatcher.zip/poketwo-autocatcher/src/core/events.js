const fs = require('fs');
const path = require('path');
const { handleCommand } = require('./commands');
const { handlePokemonSpawn } = require('../modules/autocatcher/pokemonDetector');
const { handleMarketListings } = require('../modules/market/marketScanner');
const { logger } = require('../modules/logger/logger');

// Setup event handlers
function setupEvents(client) {
  // Ready event
  client.once('ready', () => {
    logger.success(`Logged in as ${client.user.tag}`);
    client.user.setActivity(`${global.botConfig.prefix}help`, { type: 'LISTENING' });
  });
  
  // Message event
  client.on('messageCreate', async message => {
    try {
      // Handle commands
      await handleCommand(message, global.botConfig.prefix);
      
      // Check if message is from Pokétwo
      if (message.author.id === '716390085896962058') { // Pokétwo bot ID
        // Handle Pokémon spawns
        if (message.embeds.length > 0 && global.botConfig.userConfig?.autocatcher?.enabled) {
          await handlePokemonSpawn(message);
        }
        
        // Handle market listings
        if (message.embeds.length > 0 && 
            message.embeds[0].title && 
            message.embeds[0].title.includes('Market') && 
            global.botConfig.userConfig?.market?.sniper?.enabled) {
          await handleMarketListings(message);
        }
      }
    } catch (error) {
      logger.error('Error handling message:', error);
    }
  });
  
  // Message update event (for edited messages)
  client.on('messageUpdate', async (oldMessage, newMessage) => {
    try {
      // Check if message is from Pokétwo and has embeds
      if (newMessage.author && newMessage.author.id === '716390085896962058' && newMessage.embeds.length > 0) {
        // Handle Pokémon spawns in edited messages
        if (global.botConfig.userConfig?.autocatcher?.enabled) {
          await handlePokemonSpawn(newMessage);
        }
        
        // Handle market listings in edited messages
        if (newMessage.embeds[0].title && 
            newMessage.embeds[0].title.includes('Market') && 
            global.botConfig.userConfig?.market?.sniper?.enabled) {
          await handleMarketListings(newMessage);
        }
      }
    } catch (error) {
      logger.error('Error handling message update:', error);
    }
  });
  
  // Error event
  client.on('error', error => {
    logger.error('Discord client error:', error);
  });
  
  // Warning event
  client.on('warn', warning => {
    logger.warn('Discord client warning:', warning);
  });
  
  // Debug event (only in development)
  if (process.env.NODE_ENV === 'development') {
    client.on('debug', info => {
      logger.debug('Discord client debug:', info);
    });
  }
  
  // Load custom event handlers
  loadEventHandlers(client);
  
  logger.info('Event handlers set up successfully');
}

// Load custom event handlers from modules
function loadEventHandlers(client) {
  const eventsDir = path.join(__dirname, '../modules');
  
  // Check if directory exists
  if (!fs.existsSync(eventsDir)) return;
  
  // Find all event handler files
  const eventFiles = findEventFiles(eventsDir);
  
  // Load each event handler
  for (const file of eventFiles) {
    try {
      const event = require(file);
      
      if (event.name && event.execute && event.once) {
        client.once(event.name, (...args) => event.execute(...args));
        logger.debug(`Registered one-time event handler: ${event.name}`);
      } else if (event.name && event.execute) {
        client.on(event.name, (...args) => event.execute(...args));
        logger.debug(`Registered event handler: ${event.name}`);
      }
    } catch (error) {
      logger.error(`Failed to load event handler: ${file}`, error);
    }
  }
}

// Find all event handler files recursively
function findEventFiles(directory) {
  const files = [];
  
  const items = fs.readdirSync(directory, { withFileTypes: true });
  
  for (const item of items) {
    const itemPath = path.join(directory, item.name);
    
    if (item.isDirectory()) {
      // Recursively search subdirectories
      files.push(...findEventFiles(itemPath));
    } else if (item.name.endsWith('Event.js')) {
      files.push(itemPath);
    }
  }
  
  return files;
}

module.exports = {
  setupEvents
};