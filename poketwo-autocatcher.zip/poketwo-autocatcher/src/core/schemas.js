const mongoose = require('mongoose');

// Server Settings Schema
const ServerSettingsSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true
  },
  enabled: {
    type: Boolean,
    default: false
  },
  allowedChannels: {
    type: [String],
    default: []
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Catch Log Schema
const CatchLogSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true
  },
  guildId: {
    type: String,
    required: true
  },
  channelId: {
    type: String,
    required: true
  },
  pokemonName: {
    type: String,
    required: true
  },
  level: {
    type: Number
  },
  iv: {
    type: Number
  },
  types: {
    type: [String]
  },
  rarity: {
    type: String
  },
  shiny: {
    type: Boolean,
    default: false
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

// Market Log Schema
const MarketLogSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true
  },
  action: {
    type: String,
    enum: ['buy', 'sell'],
    required: true
  },
  pokemonName: {
    type: String
  },
  price: {
    type: Number,
    required: true
  },
  level: {
    type: Number
  },
  iv: {
    type: Number
  },
  shiny: {
    type: Boolean,
    default: false
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

// User Config Schema
const UserConfigSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  autocatcher: {
    enabled: {
      type: Boolean,
      default: true
    },
    filters: {
      enabled: {
        type: Boolean,
        default: false
      },
      includeNames: {
        type: [String],
        default: []
      },
      excludeNames: {
        type: [String],
        default: []
      },
      includeTypes: {
        type: [String],
        default: []
      },
      excludeTypes: {
        type: [String],
        default: []
      },
      includeRarity: {
        type: [String],
        default: []
      },
      minIV: {
        type: Number,
        default: 0
      }
    },
    delay: {
      min: {
        type: Number,
        default: 1000
      },
      max: {
        type: Number,
        default: 3000
      },
      randomize: {
        type: Boolean,
        default: true
      }
    },
    shinyHunting: {
      enabled: {
        type: Boolean,
        default: true
      }
    },
    questCompletion: {
      enabled: {
        type: Boolean,
        default: true
      }
    },
    dexCompletion: {
      enabled: {
        type: Boolean,
        default: true
      }
    },
    incenseSniper: {
      enabled: {
        type: Boolean,
        default: true
      }
    }
  },
  autoleveler: {
    enabled: {
      type: Boolean,
      default: false
    },
    mode: {
      type: String,
      enum: ['manual', 'cycle', 'scheduled'],
      default: 'manual'
    },
    queue: {
      type: [String],
      default: []
    },
    targetLevel: {
      type: Number,
      default: 100
    },
    evolution: {
      enabled: {
        type: Boolean,
        default: true
      },
      skipEvolutions: {
        type: [String],
        default: []
      }
    }
  },
  spawner: {
    enabled: {
      type: Boolean,
      default: false
    },
    mode: {
      type: String,
      enum: ['normal', 'spam', 'special'],
      default: 'normal'
    },
    interval: {
      type: Number,
      default: 15000
    },
    channels: {
      type: [String],
      default: []
    }
  },
  market: {
    sniper: {
      enabled: {
        type: Boolean,
        default: false
      },
      maxPrice: {
        type: Number,
        default: 10000
      },
      targetPokemon: {
        type: [String],
        default: []
      }
    },
    flipper: {
      enabled: {
        type: Boolean,
        default: false
      }
    },
    swiper: {
      enabled: {
        type: Boolean,
        default: false
      },
      trashPokemon: {
        type: [String],
        default: []
      },
      minPrice: {
        type: Number,
        default: 1000
      }
    }
  },
  captchaSolver: {
    enabled: {
      type: Boolean,
      default: true
    },
    method: {
      type: String,
      enum: ['local', 'api'],
      default: 'local'
    },
    apiKey: {
      type: String
    },
    apiEndpoint: {
      type: String
    }
  },
  antiDetection: {
    humanLikeTyping: {
      type: Boolean,
      default: true
    },
    randomizeMessages: {
      type: Boolean,
      default: true
    },
    activityPatterns: {
      type: Boolean,
      default: true
    }
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Pokemon Data Schema
const PokemonDataSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  dexNumber: {
    type: Number,
    required: true
  },
  types: {
    type: [String],
    required: true
  },
  rarity: {
    type: String,
    enum: ['common', 'uncommon', 'rare', 'legendary', 'mythical'],
    default: 'common'
  },
  generation: {
    type: Number
  },
  evolutions: {
    type: [String],
    default: []
  },
  baseStats: {
    hp: Number,
    attack: Number,
    defense: Number,
    spAttack: Number,
    spDefense: Number,
    speed: Number
  }
});

// Create models
const models = {
  ServerSettings: mongoose.models.ServerSettings || mongoose.model('ServerSettings', ServerSettingsSchema),
  CatchLog: mongoose.models.CatchLog || mongoose.model('CatchLog', CatchLogSchema),
  MarketLog: mongoose.models.MarketLog || mongoose.model('MarketLog', MarketLogSchema),
  UserConfig: mongoose.models.UserConfig || mongoose.model('UserConfig', UserConfigSchema),
  PokemonData: mongoose.models.PokemonData || mongoose.model('PokemonData', PokemonDataSchema)
};

module.exports = models;