const { logger } = require('../modules/logger/logger');

// Simulate human typing
async function simulateHumanTyping(channel) {
  try {
    // Get typing speed configuration
    const config = global.botConfig.userConfig?.antiDetection?.typingSpeed || { min: 50, max: 150 };
    
    // Calculate typing duration based on typing speed
    const typingDuration = Math.floor(Math.random() * (config.max - config.min + 1)) + config.min;
    
    // Start typing indicator
    await channel.sendTyping();
    
    // Wait for typing duration
    await new Promise(resolve => setTimeout(resolve, typingDuration * 10));
  } catch (error) {
    logger.error('Error simulating human typing:', error);
  }
}

// Randomize command execution
function randomizeCommandExecution(baseDelay) {
  // Add random variation to delay
  const variation = Math.random() * 0.3; // 0-30% variation
  const randomFactor = 1 - 0.15 + variation; // 0.85-1.15 multiplier
  
  return Math.floor(baseDelay * randomFactor);
}

// Simulate human-like activity patterns
async function simulateActivityPattern() {
  // This function would implement more sophisticated activity patterns
  // such as periods of inactivity, varying response times based on time of day, etc.
  
  // For now, just return a random activity score (0-1)
  // where 0 means very inactive and 1 means very active
  const hourOfDay = new Date().getHours();
  
  // Simulate lower activity during typical sleeping hours
  if (hourOfDay >= 2 && hourOfDay <= 6) {
    return Math.random() * 0.3; // 0-0.3 activity level during night
  }
  
  // Simulate peak activity during evening hours
  if (hourOfDay >= 18 && hourOfDay <= 23) {
    return 0.7 + Math.random() * 0.3; // 0.7-1.0 activity level during evening
  }
  
  // Normal activity during the day
  return 0.3 + Math.random() * 0.4; // 0.3-0.7 activity level during day
}

// Randomize message content slightly
function randomizeMessageContent(message) {
  // Only apply randomization if enabled
  if (!global.botConfig.userConfig?.antiDetection?.randomizeCommands) {
    return message;
  }
  
  // 20% chance to add a typo and then correct it
  if (Math.random() < 0.2) {
    // Split message into parts
    const parts = message.split(' ');
    
    if (parts.length > 1) {
      // Select a random word to modify
      const randomIndex = Math.floor(Math.random() * parts.length);
      const originalWord = parts[randomIndex];
      
      // Only modify words with length > 3
      if (originalWord.length > 3) {
        // Create a typo by swapping two adjacent characters
        const typoIndex = Math.floor(Math.random() * (originalWord.length - 1));
        const typoWord = originalWord.substring(0, typoIndex) + 
                         originalWord.charAt(typoIndex + 1) + 
                         originalWord.charAt(typoIndex) + 
                         originalWord.substring(typoIndex + 2);
        
        // Return the message with the typo
        parts[randomIndex] = typoWord;
        return parts.join(' ');
      }
    }
  }
  
  // 10% chance to add filler words
  if (Math.random() < 0.1) {
    const fillerWords = ['uhm', 'uh', 'hmm', 'wait', 'let me see'];
    const randomFiller = fillerWords[Math.floor(Math.random() * fillerWords.length)];
    return `${randomFiller} ${message}`;
  }
  
  return message;
}

// Detect and avoid pattern recognition
function avoidPatternRecognition(lastCommands) {
  // Analyze recent commands for patterns
  if (lastCommands.length < 5) {
    return false; // Not enough data to detect patterns
  }
  
  // Check for consistent timing patterns
  const timeDiffs = [];
  for (let i = 1; i < lastCommands.length; i++) {
    timeDiffs.push(lastCommands[i].timestamp - lastCommands[i-1].timestamp);
  }
  
  // Calculate standard deviation of time differences
  const avgTimeDiff = timeDiffs.reduce((sum, diff) => sum + diff, 0) / timeDiffs.length;
  const variance = timeDiffs.reduce((sum, diff) => sum + Math.pow(diff - avgTimeDiff, 2), 0) / timeDiffs.length;
  const stdDev = Math.sqrt(variance);
  
  // If standard deviation is very low, timing is too consistent
  if (stdDev < avgTimeDiff * 0.1) {
    logger.debug('Detected too consistent timing pattern, adding randomization');
    return true;
  }
  
  return false;
}

module.exports = {
  simulateHumanTyping,
  randomizeCommandExecution,
  simulateActivityPattern,
  randomizeMessageContent,
  avoidPatternRecognition
};