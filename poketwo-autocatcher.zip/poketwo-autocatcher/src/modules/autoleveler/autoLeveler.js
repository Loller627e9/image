const { logger } = require('../logger/logger');
const { simulateHumanTyping } = require('../../utils/antiDetection');

// Start auto-leveler
async function startAutoLeveler() {
  try {
    // Check if auto-leveler is enabled
    if (!global.botConfig.userConfig?.autoleveler?.enabled) {
      logger.info('Auto-leveler is disabled');
      return;
    }
    
    // Check if already running
    if (global.autoLevelerRunning) {
      logger.warn('Auto-leveler is already running');
      return;
    }
    
    global.autoLevelerRunning = true;
    
    logger.info('Starting auto-leveler');
    
    // Process queue based on mode
    const mode = global.botConfig.userConfig?.autoleveler?.mode || 'manual';
    
    if (mode === 'manual') {
      // Manual mode - process queue once
      await processLevelQueue();
    } else if (mode === 'cycle') {
      // Cycle mode - continuously process queue
      startCycleMode();
    } else if (mode === 'scheduled') {
      // Scheduled mode - process queue at scheduled times
      startScheduledMode();
    }
  } catch (error) {
    logger.error('Error starting auto-leveler:', error);
    global.autoLevelerRunning = false;
  }
}

// Stop auto-leveler
function stopAutoLeveler() {
  // Clear any running timers
  if (global.autoLevelerTimer) {
    clearInterval(global.autoLevelerTimer);
    global.autoLevelerTimer = null;
  }
  
  global.autoLevelerRunning = false;
  logger.info('Auto-leveler stopped');
}

// Start cycle mode
function startCycleMode() {
  // Process queue immediately
  processLevelQueue();
  
  // Set up interval to process queue periodically
  global.autoLevelerTimer = setInterval(() => {
    processLevelQueue();
  }, 60000); // Process every minute
}

// Start scheduled mode
function startScheduledMode() {
  // This is a placeholder for scheduled mode
  // In a real implementation, this would set up timers
  // to process the queue at specific times of day
  
  logger.warn('Scheduled mode not fully implemented');
  
  // For now, just process once
  processLevelQueue();
}

// Process level queue
async function processLevelQueue() {
  try {
    // Get queue from config
    const queue = global.botConfig.userConfig?.autoleveler?.queue || [];
    
    if (queue.length === 0) {
      logger.info('Auto-leveler queue is empty');
      return;
    }
    
    logger.info(`Processing auto-leveler queue (${queue.length} Pokémon)`);
    
    // Process each Pokémon in queue
    for (const pokemonId of queue) {
      await levelPokemon(pokemonId);
      
      // Add delay between Pokémon
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  } catch (error) {
    logger.error('Error processing level queue:', error);
  }
}

// Level up a Pokemon
async function levelPokemon(pokemonId) {
  try {
    // Get target level from config
    const targetLevel = global.botConfig.userConfig?.autoleveler?.targetLevel || 100;
    
    // Get Pokémon info
    const pokemonInfo = await getPokemonInfo(pokemonId);
    
    if (!pokemonInfo) {
      logger.warn(`Failed to get info for Pokémon #${pokemonId}`);
      return false;
    }
    
    logger.info(`Leveling ${pokemonInfo.name} (Level ${pokemonInfo.level}) to Level ${targetLevel}`);
    
    // Check if already at or above target level
    if (pokemonInfo.level >= targetLevel) {
      logger.info(`${pokemonInfo.name} is already at or above target level (${pokemonInfo.level})`);
      return true;
    }
    
    // Get a channel to use
    const channel = await getAvailableChannel();
    
    if (!channel) {
      logger.warn('No available channel found for auto-leveler');
      return false;
    }
    
    // Simulate human typing
    if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
      await simulateHumanTyping(channel);
    }
    
    // Send select command
    await channel.send(`${global.botConfig.prefix}select ${pokemonId}`);
    
    // Wait for response
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Calculate number of battles needed
    const battlesNeeded = Math.ceil((targetLevel - pokemonInfo.level) / 5); // Assuming ~5 levels per battle
    
    // Battle multiple times
    for (let i = 0; i < battlesNeeded; i++) {
      // Simulate human typing
      if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
        await simulateHumanTyping(channel);
      }
      
      // Send battle command
      await channel.send(`${global.botConfig.prefix}battle`);
      
      // Wait for battle to complete
      await new Promise(resolve => setTimeout(resolve, 10000));
      
      // Check for evolution
      await handleEvolution(channel);
      
      // Get updated Pokémon info
      const updatedInfo = await getPokemonInfo(pokemonId);
      
      if (!updatedInfo) {
        logger.warn(`Failed to get updated info for Pokémon #${pokemonId}`);
        continue;
      }
      
      logger.info(`${updatedInfo.name} is now Level ${updatedInfo.level}`);
      
      // Check if target level reached
      if (updatedInfo.level >= targetLevel) {
        logger.success(`${updatedInfo.name} reached target level ${targetLevel}`);
        break;
      }
    }
    
    return true;
  } catch (error) {
    logger.error(`Error leveling Pokémon #${pokemonId}:`, error);
    return false;
  }
}

// Get Pokemon info
async function getPokemonInfo(pokemonId) {
  try {
    // Get a channel to use
    const channel = await getAvailableChannel();
    
    if (!channel) {
      logger.warn('No available channel found');
      return null;
    }
    
    // Simulate human typing
    if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
      await simulateHumanTyping(channel);
    }
    
    // Send info command
    const infoMessage = await channel.send(`${global.botConfig.prefix}info ${pokemonId}`);
    
    // Wait for Pokétwo's response
    const response = await waitForPokétwoResponse(channel, infoMessage.id);
    
    if (!response || !response.embeds.length) {
      logger.warn(`No valid response for Pokémon #${pokemonId}`);
      return null;
    }
    
    // Extract info from embed
    const embed = response.embeds[0];
    
    const info = {
      id: pokemonId,
      name: null,
      level: null,
      types: [],
      iv: null,
      nature: null
    };
    
    // Extract name from title
    if (embed.title) {
      const nameMatch = embed.title.match(/^(.+?)\s*(?:Level|Lv\.)/i);
      if (nameMatch && nameMatch[1]) {
        info.name = nameMatch[1].trim();
      }
    }
    
    // Extract level from title
    if (embed.title) {
      const levelMatch = embed.title.match(/(?:Level|Lv\.)\s*(\d+)/i);
      if (levelMatch && levelMatch[1]) {
        info.level = parseInt(levelMatch[1], 10);
      }
    }
    
    // Extract other info from description
    if (embed.description) {
      // Extract types
      const typesMatch = embed.description.match(/Type(?:s)?:\s*(.+?)(?:\n|$)/i);
      if (typesMatch && typesMatch[1]) {
        info.types = typesMatch[1].split(/\s*\/\s*/).map(type => type.trim());
      }
      
      // Extract IV
      const ivMatch = embed.description.match(/(\d+(\.\d+)?)%\s*IV/i);
      if (ivMatch && ivMatch[1]) {
        info.iv = parseFloat(ivMatch[1]);
      }
      
      // Extract nature
      const natureMatch = embed.description.match(/Nature:\s*(.+?)(?:\n|$)/i);
      if (natureMatch && natureMatch[1]) {
        info.nature = natureMatch[1].trim();
      }
    }
    
    return info;
  } catch (error) {
    logger.error(`Error getting info for Pokémon #${pokemonId}:`, error);
    return null;
  }
}

// Handle evolution
async function handleEvolution(channel) {
  try {
    // Check if evolution is enabled
    if (!global.botConfig.userConfig?.autoleveler?.evolution?.enabled) {
      return;
    }
    
    // Wait for evolution message
    const evolutionMessage = await waitForEvolutionMessage(channel);
    
    if (!evolutionMessage) {
      return;
    }
    
    logger.info('Evolution detected!');
    
    // Get Pokémon name from message
    let pokemonName = null;
    if (evolutionMessage.embeds.length > 0 && evolutionMessage.embeds[0].description) {
      const nameMatch = evolutionMessage.embeds[0].description.match(/Your (.+?) is evolving/i);
      if (nameMatch && nameMatch[1]) {
        pokemonName = nameMatch[1].trim();
      }
    }
    
    // Check if this Pokémon should skip evolution
    const skipEvolutions = global.botConfig.userConfig?.autoleveler?.evolution?.skipEvolutions || [];
    
    if (pokemonName && skipEvolutions.some(name => pokemonName.toLowerCase().includes(name.toLowerCase()))) {
      logger.info(`Skipping evolution for ${pokemonName}`);
      
      // Simulate human typing
      if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
        await simulateHumanTyping(channel);
      }
      
      // Send cancel command
      await channel.send('n');
    } else {
      // Simulate human typing
      if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
        await simulateHumanTyping(channel);
      }
      
      // Send confirm command
      await channel.send('y');
      
      logger.success('Evolution confirmed!');
    }
    
    // Wait for evolution to complete
    await new Promise(resolve => setTimeout(resolve, 5000));
  } catch (error) {
    logger.error('Error handling evolution:', error);
  }
}

// Wait for evolution message
async function waitForEvolutionMessage(channel) {
  return new Promise(resolve => {
    // Set up a message collector
    const filter = m => 
      m.author.id === '716390085896962058' && // Pokétwo bot ID
      ((m.content && m.content.toLowerCase().includes('evolving')) ||
       (m.embeds.length > 0 && m.embeds[0].description && 
        m.embeds[0].description.toLowerCase().includes('evolving')));
    
    const collector = channel.createMessageCollector({ filter, time: 5000, max: 1 });
    
    collector.on('collect', message => {
      resolve(message);
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        resolve(null);
      }
    });
  });
}

// Wait for Pokétwo's response
async function waitForPokétwoResponse(channel, messageId) {
  return new Promise(resolve => {
    // Set up a message collector
    const filter = m => 
      m.author.id === '716390085896962058' && // Pokétwo bot ID
      m.reference?.messageId === messageId;
    
    const collector = channel.createMessageCollector({ filter, time: 10000, max: 1 });
    
    collector.on('collect', message => {
      resolve(message);
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        logger.warn('No response from Pokétwo');
        resolve(null);
      }
    });
  });
}

// Get an available channel
async function getAvailableChannel() {
  try {
    // Get enabled servers
    const enabledServers = Array.from(global.botConfig.enabledServers);
    
    if (enabledServers.length === 0) {
      logger.warn('No enabled servers found');
      return null;
    }
    
    // Try to find a suitable channel
    for (const serverId of enabledServers) {
      try {
        const guild = await global.client.guilds.fetch(serverId);
        
        if (!guild) continue;
        
        // Get text channels
        const channels = await guild.channels.fetch();
        
        // Filter to text channels
        const textChannels = channels.filter(channel => 
          channel.type === 'GUILD_TEXT' && 
          channel.permissionsFor(guild.me).has(['SEND_MESSAGES', 'VIEW_CHANNEL']));
        
        if (textChannels.size > 0) {
          // Return the first available channel
          return textChannels.first();
        }
      } catch (error) {
        logger.error(`Error accessing server ${serverId}:`, error);
      }
    }
    
    logger.warn('No available channels found in enabled servers');
    return null;
  } catch (error) {
    logger.error('Error finding available channel:', error);
    return null;
  }
}

module.exports = {
  startAutoLeveler,
  stopAutoLeveler,
  levelPokemon
};