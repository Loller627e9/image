const { logger } = require('../logger/logger');
const { simulateHumanTyping } = require('../../utils/antiDetection');

// Start spawner
async function startSpawner() {
  try {
    // Check if spawner is enabled
    if (!global.botConfig.userConfig?.spawner?.enabled) {
      logger.info('Spawner is disabled');
      return;
    }
    
    // Check if already running
    if (global.spawnerRunning) {
      logger.warn('Spawner is already running');
      return;
    }
    
    global.spawnerRunning = true;
    
    logger.info('Starting spawner');
    
    // Get spawner mode
    const mode = global.botConfig.userConfig?.spawner?.mode || 'normal';
    
    // Start spawner based on mode
    if (mode === 'normal') {
      startNormalSpawner();
    } else if (mode === 'spam') {
      startSpamSpawner();
    } else if (mode === 'special') {
      startSpecialSpawner();
    } else {
      logger.warn(`Unknown spawner mode: ${mode}`);
      global.spawnerRunning = false;
    }
  } catch (error) {
    logger.error('Error starting spawner:', error);
    global.spawnerRunning = false;
  }
}

// Stop spawner
function stopSpawner() {
  // Clear any running timers
  if (global.spawnerTimer) {
    clearInterval(global.spawnerTimer);
    global.spawnerTimer = null;
  }
  
  global.spawnerRunning = false;
  logger.info('Spawner stopped');
}

// Start normal spawner
function startNormalSpawner() {
  // Get interval from config
  const interval = global.botConfig.userConfig?.spawner?.interval || 15000;
  
  logger.info(`Starting normal spawner with interval ${interval}ms`);
  
  // Set up interval to spawn Pokémon periodically
  global.spawnerTimer = setInterval(async () => {
    await spawnPokemon();
  }, interval);
  
  // Spawn immediately
  spawnPokemon();
}

// Start spam spawner
function startSpamSpawner() {
  // Get interval from config (use shorter interval for spam mode)
  const interval = Math.max(1000, (global.botConfig.userConfig?.spawner?.interval || 15000) / 3);
  
  logger.info(`Starting spam spawner with interval ${interval}ms`);
  
  // Set up interval to spawn Pokémon rapidly
  global.spawnerTimer = setInterval(async () => {
    await spawnPokemon('spam');
  }, interval);
  
  // Spawn immediately
  spawnPokemon('spam');
}

// Start special spawner
function startSpecialSpawner() {
  // Get interval from config
  const interval = global.botConfig.userConfig?.spawner?.interval || 15000;
  
  logger.info(`Starting special spawner with interval ${interval}ms`);
  
  // Set up interval to spawn Pokémon periodically
  global.spawnerTimer = setInterval(async () => {
    await spawnPokemon('special');
  }, interval);
  
  // Spawn immediately
  spawnPokemon('special');
}

// Spawn Pokemon
async function spawnPokemon(mode = 'normal') {
  try {
    // Get channels from config
    const configuredChannels = global.botConfig.userConfig?.spawner?.channels || [];
    
    // If no channels configured, try to find one
    if (configuredChannels.length === 0) {
      const channel = await getRandomChannel();
      
      if (!channel) {
        logger.warn('No available channel found for spawner');
        return false;
      }
      
      await spawnInChannel(channel, mode);
    } else {
      // Use a random configured channel
      const channelId = configuredChannels[Math.floor(Math.random() * configuredChannels.length)];
      
      try {
        const channel = await global.client.channels.fetch(channelId);
        
        if (!channel) {
          logger.warn(`Channel ${channelId} not found`);
          return false;
        }
        
        await spawnInChannel(channel, mode);
      } catch (error) {
        logger.error(`Error accessing channel ${channelId}:`, error);
        return false;
      }
    }
    
    return true;
  } catch (error) {
    logger.error('Error spawning Pokémon:', error);
    return false;
  }
}

// Spawn in specific channel
async function spawnInChannel(channel, mode) {
  try {
    // Simulate human typing
    if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
      await simulateHumanTyping(channel);
    }
    
    // Choose message based on mode
    let message = '';
    
    if (mode === 'normal') {
      // Normal mode - send a random message
      message = getRandomMessage();
    } else if (mode === 'spam') {
      // Spam mode - send short random messages
      message = getRandomSpamMessage();
    } else if (mode === 'special') {
      // Special mode - send special commands
      message = getRandomSpecialCommand();
    }
    
    // Send message
    await channel.send(message);
    
    logger.debug(`Sent spawner message in #${channel.name}: ${message}`);
    
    return true;
  } catch (error) {
    logger.error(`Error spawning in channel #${channel.name}:`, error);
    return false;
  }
}

// Get random channel
async function getRandomChannel() {
  try {
    // Get enabled servers
    const enabledServers = Array.from(global.botConfig.enabledServers);
    
    if (enabledServers.length === 0) {
      logger.warn('No enabled servers found');
      return null;
    }
    
    // Choose a random server
    const serverId = enabledServers[Math.floor(Math.random() * enabledServers.length)];
    
    try {
      const guild = await global.client.guilds.fetch(serverId);
      
      if (!guild) {
        logger.warn(`Server ${serverId} not found`);
        return null;
      }
      
      // Get text channels
      const channels = await guild.channels.fetch();
      
      // Filter to text channels with permissions
      const textChannels = channels.filter(channel => 
        channel.type === 'GUILD_TEXT' && 
        channel.permissionsFor(guild.me).has(['SEND_MESSAGES', 'VIEW_CHANNEL']));
      
      if (textChannels.size === 0) {
        logger.warn(`No available text channels in server ${guild.name}`);
        return null;
      }
      
      // Choose a random channel
      const channelArray = Array.from(textChannels.values());
      return channelArray[Math.floor(Math.random() * channelArray.length)];
    } catch (error) {
      logger.error(`Error accessing server ${serverId}:`, error);
      return null;
    }
  } catch (error) {
    logger.error('Error finding random channel:', error);
    return null;
  }
}

// Get random message
function getRandomMessage() {
  const messages = [
    'Hello there!',
    'How is everyone doing today?',
    'I wonder what Pokémon will spawn next...',
    'Anyone caught any good Pokémon lately?',
    'What\'s your favorite Pokémon type?',
    'I\'m trying to complete my Pokédex!',
    'Does anyone have any rare Pokémon?',
    'I just caught a new Pokémon!',
    'Pokémon training is fun!',
    'I love collecting Pokémon!',
    'What\'s the best Pokémon for battling?',
    'I\'m looking for a shiny Pokémon!',
    'Has anyone seen a legendary Pokémon?',
    'I need more Pokéballs!',
    'Time to catch some Pokémon!'
  ];
  
  return messages[Math.floor(Math.random() * messages.length)];
}

// Get random spam message
function getRandomSpamMessage() {
  const messages = [
    'hi',
    'hello',
    'hey',
    'yo',
    'sup',
    'nice',
    'cool',
    'wow',
    'lol',
    'haha',
    'nice',
    'awesome',
    'great',
    'yes',
    'no',
    'maybe',
    'ok',
    'sure',
    'hmm',
    'interesting'
  ];
  
  return messages[Math.floor(Math.random() * messages.length)];
}

// Get random special command
function getRandomSpecialCommand() {
  const commands = [
    `${global.botConfig.prefix}help`,
    `${global.botConfig.prefix}pokemon`,
    `${global.botConfig.prefix}pokedex`,
    `${global.botConfig.prefix}daily`,
    `${global.botConfig.prefix}vote`,
    `${global.botConfig.prefix}ping`,
    `${global.botConfig.prefix}info latest`
  ];
  
  return commands[Math.floor(Math.random() * commands.length)];
}

module.exports = {
  startSpawner,
  stopSpawner,
  spawnPokemon
};