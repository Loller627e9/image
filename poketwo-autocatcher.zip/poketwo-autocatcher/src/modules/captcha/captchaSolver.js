const axios = require('axios');
const fs = require('fs');
const path = require('path');
const Jimp = require('jimp');
const Tesseract = require('tesseract.js');
const { logger } = require('../logger/logger');

// Detect captcha in message
async function detectCaptcha(message) {
  try {
    // Check if message is from Pokétwo
    if (message.author.id !== '716390085896962058') {
      return false;
    }
    
    // Check for captcha indicators in content
    const content = message.content.toLowerCase();
    if (content.includes('captcha') || 
        content.includes('verify') || 
        content.includes('human') ||
        content.includes('bot check')) {
      return true;
    }
    
    // Check for captcha in embeds
    if (message.embeds.length > 0) {
      const embed = message.embeds[0];
      
      // Check embed title and description
      if ((embed.title && (
            embed.title.toLowerCase().includes('captcha') ||
            embed.title.toLowerCase().includes('verification')
          )) ||
          (embed.description && (
            embed.description.toLowerCase().includes('captcha') ||
            embed.description.toLowerCase().includes('verify you are human')
          ))) {
        return true;
      }
      
      // Check for image (most captchas have images)
      if (embed.image) {
        return true;
      }
    }
    
    // Check for attachments
    if (message.attachments.size > 0) {
      return true;
    }
    
    return false;
  } catch (error) {
    logger.error('Error detecting captcha:', error);
    return false;
  }
}

// Solve captcha
async function solveCaptcha(message) {
  try {
    logger.warn('Captcha detected! Attempting to solve...');
    
    // Check if captcha solving is enabled
    if (!global.botConfig.userConfig?.captchaSolver?.enabled) {
      logger.warn('Captcha solver is disabled. Please solve the captcha manually.');
      return false;
    }
    
    // Get captcha image URL
    let imageUrl = null;
    
    // Check embeds for image
    if (message.embeds.length > 0 && message.embeds[0].image) {
      imageUrl = message.embeds[0].image.url;
    }
    
    // Check attachments for image
    if (!imageUrl && message.attachments.size > 0) {
      const attachment = message.attachments.first();
      if (attachment.contentType && attachment.contentType.startsWith('image/')) {
        imageUrl = attachment.url;
      }
    }
    
    if (!imageUrl) {
      logger.warn('No captcha image found');
      return false;
    }
    
    // Choose solving method based on configuration
    const method = global.botConfig.userConfig?.captchaSolver?.method || 'local';
    
    let solution = null;
    
    if (method === 'local') {
      // Solve captcha locally
      solution = await solveLocalCaptcha(imageUrl);
    } else if (method === 'api') {
      // Solve captcha using external API
      solution = await solveApiCaptcha(imageUrl);
    }
    
    if (!solution) {
      logger.warn('Failed to solve captcha');
      return false;
    }
    
    logger.info(`Captcha solution: ${solution}`);
    
    // Send solution
    await message.channel.send(solution);
    
    // Wait for response
    const success = await waitForCaptchaResponse(message.channel);
    
    if (success) {
      logger.success('Captcha solved successfully!');
    } else {
      logger.error('Captcha solution was incorrect');
    }
    
    return success;
  } catch (error) {
    logger.error('Error solving captcha:', error);
    return false;
  }
}

// Solve captcha locally using OCR
async function solveLocalCaptcha(imageUrl) {
  try {
    // Download image
    const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    const imageBuffer = Buffer.from(imageResponse.data);
    
    // Save image temporarily
    const tempImagePath = path.join(__dirname, '../../data/temp_captcha.png');
    fs.writeFileSync(tempImagePath, imageBuffer);
    
    // Process image to improve recognition
    const image = await Jimp.read(tempImagePath);
    
    // Increase contrast, convert to grayscale, and invert colors
    image.contrast(0.8).grayscale().invert();
    
    // Save processed image
    const processedImagePath = path.join(__dirname, '../../data/temp_captcha_processed.png');
    await image.writeAsync(processedImagePath);
    
    // Recognize text from image
    const { data } = await Tesseract.recognize(processedImagePath, 'eng', {
      logger: m => logger.debug(`Tesseract: ${m.status} (${Math.floor(m.progress * 100)}%)`)
    });
    
    // Clean up temporary files
    fs.unlinkSync(tempImagePath);
    fs.unlinkSync(processedImagePath);
    
    // Clean up the recognized text
    let text = data.text.trim();
    
    // Remove non-alphanumeric characters
    text = text.replace(/[^a-zA-Z0-9]/g, '');
    
    return text;
  } catch (error) {
    logger.error('Error solving captcha locally:', error);
    return null;
  }
}

// Solve captcha using external API
async function solveApiCaptcha(imageUrl) {
  try {
    const apiKey = global.botConfig.userConfig?.captchaSolver?.apiKey;
    const apiEndpoint = global.botConfig.userConfig?.captchaSolver?.apiEndpoint;
    
    if (!apiKey || !apiEndpoint) {
      logger.error('Captcha API key or endpoint not configured');
      return null;
    }
    
    // Download image
    const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    const imageBase64 = Buffer.from(imageResponse.data).toString('base64');
    
    // Send to API
    const response = await axios.post(apiEndpoint, {
      apiKey,
      image: imageBase64,
      type: 'text'
    });
    
    if (response.data && response.data.solution) {
      return response.data.solution;
    }
    
    logger.warn('API returned no solution:', response.data);
    return null;
  } catch (error) {
    logger.error('Error solving captcha with API:', error);
    return null;
  }
}

// Wait for captcha response
async function waitForCaptchaResponse(channel) {
  return new Promise(resolve => {
    // Set up a message collector
    const filter = m => 
      m.author.id === '716390085896962058'; // Pokétwo bot ID
    
    const collector = channel.createMessageCollector({ filter, time: 10000, max: 1 });
    
    collector.on('collect', message => {
      const content = message.content.toLowerCase();
      
      // Check for success indicators
      const success = content.includes('correct') || 
                     content.includes('verified') || 
                     content.includes('thank you') ||
                     content.includes('successfully');
      
      resolve(success);
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        logger.warn('No response from Pokétwo after captcha solution');
        resolve(false);
      }
    });
  });
}

module.exports = {
  detectCaptcha,
  solveCaptcha
};