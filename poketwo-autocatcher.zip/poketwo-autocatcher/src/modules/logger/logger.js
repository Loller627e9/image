const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const moment = require('moment');

// Log levels
const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  SUCCESS: 2,
  WARN: 3,
  ERROR: 4,
  NONE: 5
};

// Default log level
let currentLogLevel = LOG_LEVELS.INFO;

// Log directory
const logDir = path.join(__dirname, '../../../logs');

// Ensure log directory exists
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// Current log file
const logFile = path.join(logDir, `${moment().format('YYYY-MM-DD')}.log`);

// Format log message
function formatLogMessage(level, message, details) {
  const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
  let formattedMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  
  if (details) {
    if (typeof details === 'object') {
      try {
        formattedMessage += `\n${JSON.stringify(details, null, 2)}`;
      } catch (error) {
        formattedMessage += `\n${details}`;
      }
    } else {
      formattedMessage += `\n${details}`;
    }
  }
  
  return formattedMessage;
}

// Write to log file
function writeToLogFile(message) {
  fs.appendFileSync(logFile, message + '\n');
}

// Logger functions
const logger = {
  setLogLevel: (level) => {
    if (typeof level === 'string') {
      level = LOG_LEVELS[level.toUpperCase()] || LOG_LEVELS.INFO;
    }
    currentLogLevel = level;
  },
  
  debug: (message, details) => {
    if (currentLogLevel <= LOG_LEVELS.DEBUG) {
      const logMessage = formatLogMessage('debug', message, details);
      console.log(chalk.gray(logMessage));
      writeToLogFile(logMessage);
    }
  },
  
  info: (message, details) => {
    if (currentLogLevel <= LOG_LEVELS.INFO) {
      const logMessage = formatLogMessage('info', message, details);
      console.log(chalk.blue(logMessage));
      writeToLogFile(logMessage);
    }
  },
  
  success: (message, details) => {
    if (currentLogLevel <= LOG_LEVELS.SUCCESS) {
      const logMessage = formatLogMessage('success', message, details);
      console.log(chalk.green(logMessage));
      writeToLogFile(logMessage);
    }
  },
  
  warn: (message, details) => {
    if (currentLogLevel <= LOG_LEVELS.WARN) {
      const logMessage = formatLogMessage('warn', message, details);
      console.log(chalk.yellow(logMessage));
      writeToLogFile(logMessage);
    }
  },
  
  error: (message, details) => {
    if (currentLogLevel <= LOG_LEVELS.ERROR) {
      const logMessage = formatLogMessage('error', message, details);
      console.error(chalk.red(logMessage));
      writeToLogFile(logMessage);
    }
  },
  
  // Special logger for Pokémon catches
  catch: (pokemon, details) => {
    if (currentLogLevel <= LOG_LEVELS.INFO) {
      const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
      let logMessage = `[${timestamp}] [CATCH] Caught ${pokemon}`;
      
      if (details) {
        logMessage += ` (${Object.entries(details).map(([key, value]) => `${key}: ${value}`).join(', ')})`;
      }
      
      console.log(chalk.magenta(logMessage));
      writeToLogFile(logMessage);
      
      // Log to special catch log file
      const catchLogFile = path.join(logDir, 'catches.log');
      fs.appendFileSync(catchLogFile, logMessage + '\n');
    }
  },
  
  // Special logger for market activities
  market: (action, pokemon, price, details) => {
    if (currentLogLevel <= LOG_LEVELS.INFO) {
      const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
      let logMessage = `[${timestamp}] [MARKET] ${action} ${pokemon} for ${price}`;
      
      if (details) {
        logMessage += ` (${Object.entries(details).map(([key, value]) => `${key}: ${value}`).join(', ')})`;
      }
      
      console.log(chalk.cyan(logMessage));
      writeToLogFile(logMessage);
      
      // Log to special market log file
      const marketLogFile = path.join(logDir, 'market.log');
      fs.appendFileSync(marketLogFile, logMessage + '\n');
    }
  }
};

module.exports = {
  logger,
  LOG_LEVELS
};