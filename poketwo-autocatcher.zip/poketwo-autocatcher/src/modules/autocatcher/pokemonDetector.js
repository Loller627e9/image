const axios = require('axios');
const fs = require('fs');
const path = require('path');
const Jimp = require('jimp');
const Tesseract = require('tesseract.js');
const levenshtein = require('levenshtein-edit-distance');
const { logger } = require('../logger/logger');
const { catchPokemon } = require('./pokemonCatcher');

// Pokemon database path
const pokemonDbPath = path.join(__dirname, '../../data/pokemon/database.json');

// Load Pokemon database
let pokemonDatabase = [];
try {
  if (fs.existsSync(pokemonDbPath)) {
    pokemonDatabase = JSON.parse(fs.readFileSync(pokemonDbPath, 'utf8'));
    logger.info(`Loaded ${pokemonDatabase.length} Pokémon from database`);
  } else {
    logger.warn('Pokémon database not found. Will create one when needed.');
  }
} catch (error) {
  logger.error('Failed to load Pokémon database:', error);
}

// Handle Pokemon spawn message
async function handlePokemonSpawn(message) {
  try {
    // Check if message has embeds and is from Pokétwo
    if (!message.embeds.length || message.author.id !== '716390085896962058') {
      return;
    }
    
    const embed = message.embeds[0];
    
    // Check if this is a wild Pokémon spawn
    if (!embed.title || !embed.title.includes('wild pokémon has appeared!')) {
      return;
    }
    
    // Check if the server is enabled for autocatching
    if (!global.botConfig.enabledServers.has(message.guild.id)) {
      logger.debug(`Ignoring Pokémon spawn in disabled server: ${message.guild.name}`);
      return;
    }
    
    logger.info(`Wild Pokémon detected in ${message.guild.name} / #${message.channel.name}`);
    
    // Get the Pokémon image URL
    const imageUrl = embed.image?.url;
    if (!imageUrl) {
      logger.warn('No image found in Pokémon spawn message');
      return;
    }
    
    // Identify the Pokémon
    const pokemonName = await identifyPokemon(imageUrl);
    if (!pokemonName) {
      logger.warn('Failed to identify Pokémon');
      return;
    }
    
    logger.info(`Identified Pokémon: ${pokemonName}`);
    
    // Check filters
    if (!passesFilters(pokemonName)) {
      logger.info(`Skipping ${pokemonName} due to filters`);
      return;
    }
    
    // Add to catch queue
    global.botConfig.catchQueue.push({
      channelId: message.channel.id,
      messageId: message.id,
      pokemonName,
      timestamp: Date.now()
    });
    
    // Process catch queue
    processCatchQueue();
  } catch (error) {
    logger.error('Error handling Pokémon spawn:', error);
  }
}

// Identify Pokemon from image
async function identifyPokemon(imageUrl) {
  try {
    // Download image
    const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    const imageBuffer = Buffer.from(imageResponse.data);
    
    // Save image temporarily
    const tempImagePath = path.join(__dirname, '../../data/temp_pokemon.png');
    fs.writeFileSync(tempImagePath, imageBuffer);
    
    // Process image to improve recognition
    const image = await Jimp.read(tempImagePath);
    
    // Increase contrast and convert to grayscale
    image.contrast(0.5).grayscale();
    
    // Save processed image
    const processedImagePath = path.join(__dirname, '../../data/temp_pokemon_processed.png');
    await image.writeAsync(processedImagePath);
    
    // Recognize text from image
    const { data } = await Tesseract.recognize(processedImagePath, 'eng');
    
    // Clean up temporary files
    fs.unlinkSync(tempImagePath);
    fs.unlinkSync(processedImagePath);
    
    // If no text was recognized, try silhouette matching
    if (!data.text || data.text.trim() === '') {
      return matchPokemonSilhouette(imageBuffer);
    }
    
    // Find the closest matching Pokémon name
    return findClosestPokemonName(data.text);
  } catch (error) {
    logger.error('Error identifying Pokémon:', error);
    return null;
  }
}

// Match Pokemon silhouette
async function matchPokemonSilhouette(imageBuffer) {
  // This is a placeholder for silhouette matching
  // In a real implementation, this would use image recognition techniques
  // to match the silhouette against a database of Pokémon silhouettes
  
  logger.warn('Silhouette matching not implemented yet');
  return null;
}

// Find closest Pokemon name using Levenshtein distance
function findClosestPokemonName(text) {
  // Clean up the text
  const cleanText = text.toLowerCase().replace(/[^a-z0-9\s]/g, '');
  
  // Extract potential Pokémon names (words with 4+ characters)
  const words = cleanText.split(/\s+/).filter(word => word.length >= 4);
  
  if (words.length === 0) {
    return null;
  }
  
  let bestMatch = null;
  let bestDistance = Infinity;
  
  // Compare each word against the Pokémon database
  for (const word of words) {
    for (const pokemon of pokemonDatabase) {
      const distance = levenshtein(word, pokemon.name.toLowerCase());
      
      // If exact match, return immediately
      if (distance === 0) {
        return pokemon.name;
      }
      
      // Update best match if this is closer
      if (distance < bestDistance) {
        bestDistance = distance;
        bestMatch = pokemon.name;
      }
    }
  }
  
  // Only return if the match is reasonably close (distance less than 30% of name length)
  if (bestMatch && bestDistance < bestMatch.length * 0.3) {
    return bestMatch;
  }
  
  return null;
}

// Check if Pokemon passes filters
function passesFilters(pokemonName) {
  const filters = global.botConfig.userConfig?.autocatcher?.filters;
  
  // If filters are disabled, always pass
  if (!filters || !filters.enabled) {
    return true;
  }
  
  // Find Pokemon in database
  const pokemon = pokemonDatabase.find(p => p.name.toLowerCase() === pokemonName.toLowerCase());
  
  if (!pokemon) {
    // If Pokemon is not in database, default to passing the filter
    return true;
  }
  
  // Check include/exclude name filters
  if (filters.includeNames && filters.includeNames.length > 0) {
    if (!filters.includeNames.some(name => name.toLowerCase() === pokemonName.toLowerCase())) {
      return false;
    }
  }
  
  if (filters.excludeNames && filters.excludeNames.length > 0) {
    if (filters.excludeNames.some(name => name.toLowerCase() === pokemonName.toLowerCase())) {
      return false;
    }
  }
  
  // Check include/exclude type filters
  if (filters.includeTypes && filters.includeTypes.length > 0) {
    if (!pokemon.types || !pokemon.types.some(type => filters.includeTypes.includes(type))) {
      return false;
    }
  }
  
  if (filters.excludeTypes && filters.excludeTypes.length > 0) {
    if (pokemon.types && pokemon.types.some(type => filters.excludeTypes.includes(type))) {
      return false;
    }
  }
  
  // Check rarity filter
  if (filters.includeRarity && filters.includeRarity.length > 0) {
    if (!pokemon.rarity || !filters.includeRarity.includes(pokemon.rarity)) {
      return false;
    }
  }
  
  // All filters passed
  return true;
}

// Process catch queue
async function processCatchQueue() {
  // Check if already processing
  if (global.processingCatchQueue) {
    return;
  }
  
  global.processingCatchQueue = true;
  
  try {
    while (global.botConfig.catchQueue.length > 0) {
      const catchItem = global.botConfig.catchQueue.shift();
      
      // Calculate delay based on config
      const delay = calculateCatchDelay();
      
      // Wait for the delay
      await new Promise(resolve => setTimeout(resolve, delay));
      
      // Attempt to catch the Pokémon
      await catchPokemon(catchItem);
    }
  } catch (error) {
    logger.error('Error processing catch queue:', error);
  } finally {
    global.processingCatchQueue = false;
  }
}

// Calculate catch delay based on config
function calculateCatchDelay() {
  const delayConfig = global.botConfig.userConfig?.autocatcher?.delay;
  
  if (!delayConfig) {
    return 2000; // Default 2 seconds
  }
  
  const minDelay = delayConfig.min || 1000;
  const maxDelay = delayConfig.max || 3000;
  
  if (delayConfig.randomize) {
    return Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
  } else {
    return minDelay;
  }
}

module.exports = {
  handlePokemonSpawn,
  identifyPokemon,
  findClosestPokemonName
};