const { logger } = require('../logger/logger');
const { models } = require('../../core/database');
const { simulateHumanTyping } = require('../../utils/antiDetection');

// Catch Pokemon
async function catchPokemon(catchItem) {
  try {
    const { channelId, pokemonName, timestamp } = catchItem;
    
    // Get channel
    const channel = await global.client.channels.fetch(channelId);
    if (!channel) {
      logger.warn(`Channel ${channelId} not found`);
      return false;
    }
    
    // Get config
    const config = global.botConfig.userConfig?.autocatcher;
    
    // Simulate human typing
    if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
      await simulateHumanTyping(channel);
    }
    
    // Send catch command
    const catchMessage = await channel.send(`${global.botConfig.prefix}catch ${pokemonName}`);
    
    logger.info(`Sent catch command for ${pokemonName} in #${channel.name}`);
    
    // Wait for Pokétwo's response
    const response = await waitForPokétwoResponse(channel, catchMessage.id);
    
    // Process the response
    if (response) {
      const success = processCatchResponse(response, pokemonName);
      
      // Log the catch
      if (success) {
        // Extract additional info from response
        const pokemonInfo = extractPokemonInfo(response);
        
        // Log to database if available
        if (models.CatchLog) {
          try {
            await models.CatchLog.create({
              userId: global.client.user.id,
              pokemonName,
              level: pokemonInfo.level,
              iv: pokemonInfo.iv,
              shiny: pokemonInfo.shiny,
              channelId,
              guildId: channel.guild.id
            });
          } catch (dbError) {
            logger.error('Failed to log catch to database:', dbError);
          }
        }
        
        // Log to console/file
        logger.catch(pokemonName, pokemonInfo);
        
        // Check for rare Pokémon notifications
        if (shouldNotify(pokemonName, pokemonInfo)) {
          sendNotification(pokemonName, pokemonInfo);
        }
      }
      
      return success;
    }
    
    return false;
  } catch (error) {
    logger.error('Error catching Pokémon:', error);
    return false;
  }
}

// Wait for Pokétwo's response
async function waitForPokétwoResponse(channel, messageId) {
  return new Promise(resolve => {
    // Set up a message collector
    const filter = m => 
      m.author.id === '716390085896962058' && // Pokétwo bot ID
      m.reference?.messageId === messageId;
    
    const collector = channel.createMessageCollector({ filter, time: 10000, max: 1 });
    
    collector.on('collect', message => {
      resolve(message);
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        logger.warn('No response from Pokétwo');
        resolve(null);
      }
    });
  });
}

// Process catch response
function processCatchResponse(response, pokemonName) {
  const content = response.content.toLowerCase();
  
  // Check for successful catch
  if (content.includes('congratulations') || content.includes('you caught')) {
    return true;
  }
  
  // Check for incorrect guess
  if (content.includes('that's not the right pokémon') || content.includes('that's not right')) {
    logger.warn(`Incorrect Pokémon guess: ${pokemonName}`);
    return false;
  }
  
  // Check for too late
  if (content.includes('too late') || content.includes('already caught')) {
    logger.warn('Too late to catch the Pokémon');
    return false;
  }
  
  // Default to failure
  logger.warn(`Unknown response from Pokétwo: ${content}`);
  return false;
}

// Extract Pokemon info from response
function extractPokemonInfo(response) {
  const content = response.content;
  const info = {
    level: null,
    iv: null,
    shiny: false
  };
  
  // Extract level
  const levelMatch = content.match(/level\s*(\d+)/i);
  if (levelMatch && levelMatch[1]) {
    info.level = parseInt(levelMatch[1], 10);
  }
  
  // Extract IV
  const ivMatch = content.match(/(\d+(\.\d+)?)%\s*IV/i);
  if (ivMatch && ivMatch[1]) {
    info.iv = parseFloat(ivMatch[1]);
  }
  
  // Check if shiny
  info.shiny = content.toLowerCase().includes('✨') || content.toLowerCase().includes('shiny');
  
  return info;
}

// Check if notification should be sent
function shouldNotify(pokemonName, pokemonInfo) {
  const notificationConfig = global.botConfig.userConfig?.logger?.notifications;
  
  if (!notificationConfig) {
    return false;
  }
  
  // Find Pokemon in database
  const pokemon = global.pokemonDatabase?.find(p => p.name.toLowerCase() === pokemonName.toLowerCase());
  
  // Check rarity-based notifications
  if (pokemon) {
    if (pokemon.rarity === 'legendary' && notificationConfig.legendary) {
      return true;
    }
    
    if (pokemon.rarity === 'mythical' && notificationConfig.mythical) {
      return true;
    }
  }
  
  // Check shiny notification
  if (pokemonInfo.shiny && notificationConfig.shiny) {
    return true;
  }
  
  // Check high IV notification
  if (pokemonInfo.iv && notificationConfig.highIV && 
      pokemonInfo.iv >= (notificationConfig.highIVThreshold || 80)) {
    return true;
  }
  
  return false;
}

// Send notification
function sendNotification(pokemonName, pokemonInfo) {
  // This is a placeholder for sending notifications
  // In a real implementation, this could send Discord DMs, push notifications, etc.
  
  let notificationMessage = `🔔 Special Pokémon caught: ${pokemonName}`;
  
  if (pokemonInfo.level) {
    notificationMessage += ` (Level ${pokemonInfo.level})`;
  }
  
  if (pokemonInfo.iv) {
    notificationMessage += ` - ${pokemonInfo.iv}% IV`;
  }
  
  if (pokemonInfo.shiny) {
    notificationMessage += ' ✨ SHINY ✨';
  }
  
  logger.info(notificationMessage);
  
  // TODO: Implement actual notification system (Discord DM, webhook, etc.)
}

module.exports = {
  catchPokemon
};