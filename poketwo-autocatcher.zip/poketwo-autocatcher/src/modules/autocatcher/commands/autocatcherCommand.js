const { MessageEmbed } = require('discord.js');
const { logger } = require('../../logger/logger');
const { updateConfig } = require('../../../core/config');

module.exports = {
  name: 'autocatcher',
  description: 'Control the AutoCatcher feature',
  aliases: ['ac', 'catcher'],
  usage: '<enable|disable|status|filter>',
  serverOnly: true,
  async execute(message, args) {
    try {
      // Check if server is enabled
      if (!global.botConfig.enabledServers.has(message.guild.id)) {
        return message.reply(`The bot is not enabled in this server. Use \`${global.botConfig.prefix}enable\` to enable it.`);
      }
      
      // Check for subcommand
      if (!args.length) {
        return message.reply(`Please specify a subcommand. Use \`${global.botConfig.prefix}help autocatcher\` for more information.`);
      }
      
      const subcommand = args[0].toLowerCase();
      
      if (subcommand === 'enable') {
        // Enable AutoCatcher
        await updateConfig('autocatcher', 'enabled', true);
        
        const embed = new MessageEmbed()
          .setColor('#00ff00')
          .setTitle('AutoCatcher Enabled')
          .setDescription('The AutoCatcher feature has been enabled.')
          .setFooter({ text: `Use "${global.botConfig.prefix}autocatcher disable" to disable it` });
        
        logger.info(`AutoCatcher enabled by ${message.author.tag}`);
        
        return message.channel.send({ embeds: [embed] });
      } else if (subcommand === 'disable') {
        // Disable AutoCatcher
        await updateConfig('autocatcher', 'enabled', false);
        
        const embed = new MessageEmbed()
          .setColor('#ff0000')
          .setTitle('AutoCatcher Disabled')
          .setDescription('The AutoCatcher feature has been disabled.')
          .setFooter({ text: `Use "${global.botConfig.prefix}autocatcher enable" to enable it` });
        
        logger.info(`AutoCatcher disabled by ${message.author.tag}`);
        
        return message.channel.send({ embeds: [embed] });
      } else if (subcommand === 'status') {
        // Show AutoCatcher status
        const config = global.botConfig.userConfig?.autocatcher;
        
        const embed = new MessageEmbed()
          .setColor('#0099ff')
          .setTitle('AutoCatcher Status')
          .addField('Status', config?.enabled ? '✅ Enabled' : '❌ Disabled')
          .addField('Filters', config?.filters?.enabled ? '✅ Enabled' : '❌ Disabled')
          .addField('Delay', `${config?.delay?.min || 1000}ms - ${config?.delay?.max || 3000}ms`)
          .addField('Randomize Delay', config?.delay?.randomize ? '✅ Enabled' : '❌ Disabled')
          .addField('Shiny Hunting', config?.shinyHunting?.enabled ? '✅ Enabled' : '❌ Disabled')
          .addField('Quest Completion', config?.questCompletion?.enabled ? '✅ Enabled' : '❌ Disabled')
          .addField('Dex Completion', config?.dexCompletion?.enabled ? '✅ Enabled' : '❌ Disabled')
          .addField('Incense Sniper', config?.incenseSniper?.enabled ? '✅ Enabled' : '❌ Disabled');
        
        return message.channel.send({ embeds: [embed] });
      } else if (subcommand === 'filter') {
        // Handle filter subcommands
        if (args.length < 2) {
          return message.reply(`Please specify a filter action. Use \`${global.botConfig.prefix}help autocatcher\` for more information.`);
        }
        
        const filterAction = args[1].toLowerCase();
        
        if (filterAction === 'enable') {
          // Enable filters
          await updateConfig('autocatcher', 'filters.enabled', true);
          
          const embed = new MessageEmbed()
            .setColor('#00ff00')
            .setTitle('AutoCatcher Filters Enabled')
            .setDescription('The AutoCatcher filters have been enabled.');
          
          return message.channel.send({ embeds: [embed] });
        } else if (filterAction === 'disable') {
          // Disable filters
          await updateConfig('autocatcher', 'filters.enabled', false);
          
          const embed = new MessageEmbed()
            .setColor('#ff0000')
            .setTitle('AutoCatcher Filters Disabled')
            .setDescription('The AutoCatcher filters have been disabled.');
          
          return message.channel.send({ embeds: [embed] });
        } else if (filterAction === 'add') {
          // Add filter
          if (args.length < 4) {
            return message.reply('Please specify a filter type and value.');
          }
          
          const filterType = args[2].toLowerCase();
          const filterValue = args.slice(3).join(' ');
          
          if (filterType === 'name') {
            // Add name filter
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeNames || [];
            currentFilters.push(filterValue);
            
            await updateConfig('autocatcher', 'filters.includeNames', currentFilters);
            
            const embed = new MessageEmbed()
              .setColor('#00ff00')
              .setTitle('Filter Added')
              .setDescription(`Added "${filterValue}" to name filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else if (filterType === 'type') {
            // Add type filter
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeTypes || [];
            currentFilters.push(filterValue);
            
            await updateConfig('autocatcher', 'filters.includeTypes', currentFilters);
            
            const embed = new MessageEmbed()
              .setColor('#00ff00')
              .setTitle('Filter Added')
              .setDescription(`Added "${filterValue}" to type filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else if (filterType === 'rarity') {
            // Add rarity filter
            const validRarities = ['common', 'uncommon', 'rare', 'legendary', 'mythical'];
            
            if (!validRarities.includes(filterValue.toLowerCase())) {
              return message.reply(`Invalid rarity. Valid options are: ${validRarities.join(', ')}`);
            }
            
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeRarity || [];
            currentFilters.push(filterValue.toLowerCase());
            
            await updateConfig('autocatcher', 'filters.includeRarity', currentFilters);
            
            const embed = new MessageEmbed()
              .setColor('#00ff00')
              .setTitle('Filter Added')
              .setDescription(`Added "${filterValue}" to rarity filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else {
            return message.reply(`Invalid filter type. Valid options are: name, type, rarity`);
          }
        } else if (filterAction === 'remove') {
          // Remove filter
          if (args.length < 4) {
            return message.reply('Please specify a filter type and value.');
          }
          
          const filterType = args[2].toLowerCase();
          const filterValue = args.slice(3).join(' ');
          
          if (filterType === 'name') {
            // Remove name filter
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeNames || [];
            const newFilters = currentFilters.filter(f => f !== filterValue);
            
            await updateConfig('autocatcher', 'filters.includeNames', newFilters);
            
            const embed = new MessageEmbed()
              .setColor('#ff0000')
              .setTitle('Filter Removed')
              .setDescription(`Removed "${filterValue}" from name filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else if (filterType === 'type') {
            // Remove type filter
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeTypes || [];
            const newFilters = currentFilters.filter(f => f !== filterValue);
            
            await updateConfig('autocatcher', 'filters.includeTypes', newFilters);
            
            const embed = new MessageEmbed()
              .setColor('#ff0000')
              .setTitle('Filter Removed')
              .setDescription(`Removed "${filterValue}" from type filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else if (filterType === 'rarity') {
            // Remove rarity filter
            const currentFilters = global.botConfig.userConfig?.autocatcher?.filters?.includeRarity || [];
            const newFilters = currentFilters.filter(f => f !== filterValue.toLowerCase());
            
            await updateConfig('autocatcher', 'filters.includeRarity', newFilters);
            
            const embed = new MessageEmbed()
              .setColor('#ff0000')
              .setTitle('Filter Removed')
              .setDescription(`Removed "${filterValue}" from rarity filters.`);
            
            return message.channel.send({ embeds: [embed] });
          } else {
            return message.reply(`Invalid filter type. Valid options are: name, type, rarity`);
          }
        } else if (filterAction === 'list') {
          // List filters
          const filters = global.botConfig.userConfig?.autocatcher?.filters;
          
          const embed = new MessageEmbed()
            .setColor('#0099ff')
            .setTitle('AutoCatcher Filters')
            .addField('Status', filters?.enabled ? '✅ Enabled' : '❌ Disabled')
            .addField('Name Filters', filters?.includeNames?.length ? filters.includeNames.join(', ') : 'None')
            .addField('Type Filters', filters?.includeTypes?.length ? filters.includeTypes.join(', ') : 'None')
            .addField('Rarity Filters', filters?.includeRarity?.length ? filters.includeRarity.join(', ') : 'None')
            .addField('Excluded Names', filters?.excludeNames?.length ? filters.excludeNames.join(', ') : 'None')
            .addField('Excluded Types', filters?.excludeTypes?.length ? filters.excludeTypes.join(', ') : 'None')
            .addField('Minimum IV', filters?.minIV ? `${filters.minIV}%` : 'None');
          
          return message.channel.send({ embeds: [embed] });
        } else {
          return message.reply(`Invalid filter action. Valid options are: enable, disable, add, remove, list`);
        }
      } else {
        return message.reply(`Invalid subcommand. Use \`${global.botConfig.prefix}help autocatcher\` for more information.`);
      }
    } catch (error) {
      logger.error('Error executing autocatcher command:', error);
      return message.reply('An error occurred while executing the command.');
    }
  }
};