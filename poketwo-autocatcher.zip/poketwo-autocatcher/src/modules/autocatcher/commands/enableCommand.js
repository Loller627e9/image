const { MessageEmbed } = require('discord.js');
const { logger } = require('../../logger/logger');
const { models } = require('../../../core/database');

module.exports = {
  name: 'enable',
  description: 'Enable the bot in this server',
  serverOnly: true,
  permissions: ['ADMINISTRATOR'],
  async execute(message, args) {
    try {
      const guildId = message.guild.id;
      
      // Check if already enabled
      if (global.botConfig.enabledServers.has(guildId)) {
        return message.reply('The bot is already enabled in this server.');
      }
      
      // Add to enabled servers
      global.botConfig.enabledServers.add(guildId);
      
      // Update database if available
      if (models.ServerSettings) {
        try {
          await models.ServerSettings.findOneAndUpdate(
            { guildId },
            { 
              guildId,
              enabled: true,
              allowedChannels: [message.channel.id],
              updatedAt: new Date()
            },
            { upsert: true, new: true }
          );
        } catch (dbError) {
          logger.error('Failed to update server settings in database:', dbError);
        }
      }
      
      // Create embed
      const embed = new MessageEmbed()
        .setColor('#00ff00')
        .setTitle('Bot Enabled')
        .setDescription(`The bot has been enabled in this server.`)
        .addField('Server', message.guild.name)
        .addField('Enabled By', message.author.tag)
        .addField('Channel', `<#${message.channel.id}>`)
        .setFooter({ text: `Use "${global.botConfig.prefix}disable" to disable the bot` });
      
      logger.info(`Bot enabled in server: ${message.guild.name} (${guildId})`);
      
      return message.channel.send({ embeds: [embed] });
    } catch (error) {
      logger.error('Error enabling bot:', error);
      return message.reply('An error occurred while enabling the bot.');
    }
  }
};