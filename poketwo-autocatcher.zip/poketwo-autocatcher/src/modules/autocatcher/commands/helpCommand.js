const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'help',
  description: 'Shows help information for the bot',
  aliases: ['commands', 'h'],
  usage: '[command]',
  execute(message, args) {
    const { commands } = message.client;
    const prefix = global.botConfig.prefix;
    
    // Create embed
    const embed = new MessageEmbed()
      .setColor('#ee1515')
      .setTitle('Pokétwo AutoCatcher Help')
      .setDescription(`Here are all the available commands. Use \`${prefix}help [command]\` for more info on a specific command.`)
      .setFooter({ text: `Version ${global.botConfig.version}` });
    
    if (args.length) {
      // Show help for specific command
      const commandName = args[0].toLowerCase();
      const command = commands.get(commandName) || commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
      
      if (!command) {
        return message.reply(`Command \`${commandName}\` not found.`);
      }
      
      embed.setTitle(`Command: ${prefix}${command.name}`);
      
      if (command.description) embed.addField('Description', command.description);
      if (command.aliases) embed.addField('Aliases', command.aliases.join(', '));
      if (command.usage) embed.addField('Usage', `${prefix}${command.name} ${command.usage}`);
      
      return message.channel.send({ embeds: [embed] });
    } else {
      // Show all commands grouped by category
      const categories = {};
      
      commands.forEach(command => {
        // Skip hidden commands
        if (command.hidden) return;
        
        // Get category from command file path
        const filePath = command.filePath || '';
        const category = filePath.includes('/') ? filePath.split('/').slice(-2)[0] : 'General';
        
        // Initialize category if it doesn't exist
        if (!categories[category]) {
          categories[category] = [];
        }
        
        // Add command to category
        categories[category].push(command);
      });
      
      // Add fields for each category
      for (const [category, cmds] of Object.entries(categories)) {
        const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
        const commandList = cmds.map(cmd => `\`${cmd.name}\``).join(', ');
        
        embed.addField(categoryName, commandList);
      }
      
      return message.channel.send({ embeds: [embed] });
    }
  }
};