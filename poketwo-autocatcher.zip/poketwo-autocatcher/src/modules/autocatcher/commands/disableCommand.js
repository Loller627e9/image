const { MessageEmbed } = require('discord.js');
const { logger } = require('../../logger/logger');
const { models } = require('../../../core/database');

module.exports = {
  name: 'disable',
  description: 'Disable the bot in this server',
  serverOnly: true,
  permissions: ['ADMINISTRATOR'],
  async execute(message, args) {
    try {
      const guildId = message.guild.id;
      
      // Check if already disabled
      if (!global.botConfig.enabledServers.has(guildId)) {
        return message.reply('The bot is already disabled in this server.');
      }
      
      // Remove from enabled servers
      global.botConfig.enabledServers.delete(guildId);
      
      // Update database if available
      if (models.ServerSettings) {
        try {
          await models.ServerSettings.findOneAndUpdate(
            { guildId },
            { 
              enabled: false,
              updatedAt: new Date()
            },
            { upsert: true, new: true }
          );
        } catch (dbError) {
          logger.error('Failed to update server settings in database:', dbError);
        }
      }
      
      // Create embed
      const embed = new MessageEmbed()
        .setColor('#ff0000')
        .setTitle('Bot Disabled')
        .setDescription(`The bot has been disabled in this server.`)
        .addField('Server', message.guild.name)
        .addField('Disabled By', message.author.tag)
        .setFooter({ text: `Use "${global.botConfig.prefix}enable" to enable the bot again` });
      
      logger.info(`Bot disabled in server: ${message.guild.name} (${guildId})`);
      
      return message.channel.send({ embeds: [embed] });
    } catch (error) {
      logger.error('Error disabling bot:', error);
      return message.reply('An error occurred while disabling the bot.');
    }
  }
};