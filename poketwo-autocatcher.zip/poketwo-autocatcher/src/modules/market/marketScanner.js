const { logger } = require('../logger/logger');
const { models } = require('../../core/database');
const { simulateHumanTyping } = require('../../utils/antiDetection');

// Handle market listings
async function handleMarketListings(message) {
  try {
    // Check if message has embeds and is from Pokétwo
    if (!message.embeds.length || message.author.id !== '716390085896962058') {
      return;
    }
    
    const embed = message.embeds[0];
    
    // Check if this is a market listing
    if (!embed.title || !embed.title.includes('Market')) {
      return;
    }
    
    // Check if market features are enabled
    if (!global.botConfig.userConfig?.market?.sniper?.enabled) {
      return;
    }
    
    logger.info('Market listings detected');
    
    // Parse market listings
    const listings = parseMarketListings(embed);
    
    if (!listings.length) {
      logger.debug('No valid listings found');
      return;
    }
    
    logger.info(`Found ${listings.length} market listings`);
    
    // Process listings based on active market features
    if (global.botConfig.userConfig?.market?.sniper?.enabled) {
      await processSniper(message.channel, listings);
    }
    
    if (global.botConfig.userConfig?.market?.flipper?.enabled) {
      await processFlipper(message.channel, listings);
    }
    
    if (global.botConfig.userConfig?.market?.swiper?.enabled) {
      await processSwiper(message.channel, listings);
    }
  } catch (error) {
    logger.error('Error handling market listings:', error);
  }
}

// Parse market listings from embed
function parseMarketListings(embed) {
  const listings = [];
  
  // Check if embed has description
  if (!embed.description) {
    return listings;
  }
  
  // Split description into lines
  const lines = embed.description.split('\\n');
  
  // Parse each line
  for (const line of lines) {
    try {
      // Extract listing ID
      const idMatch = line.match(/`#(\d+)`/);
      if (!idMatch) continue;
      
      const id = idMatch[1];
      
      // Extract Pokémon name
      const nameMatch = line.match(/\*\*([^*]+)\*\*/);
      if (!nameMatch) continue;
      
      const name = nameMatch[1].trim();
      
      // Extract level
      const levelMatch = line.match(/Level (\d+)/i);
      const level = levelMatch ? parseInt(levelMatch[1], 10) : null;
      
      // Extract IV
      const ivMatch = line.match(/(\d+(\.\d+)?)%/);
      const iv = ivMatch ? parseFloat(ivMatch[1]) : null;
      
      // Extract price
      const priceMatch = line.match(/(\d+,?)+/);
      const price = priceMatch ? parseInt(priceMatch[0].replace(/,/g, ''), 10) : null;
      
      // Check if shiny
      const shiny = line.includes('✨');
      
      // Add to listings
      listings.push({
        id,
        name,
        level,
        iv,
        price,
        shiny
      });
    } catch (error) {
      logger.error('Error parsing market listing:', error);
    }
  }
  
  return listings;
}

// Process market sniper
async function processSniper(channel, listings) {
  try {
    const sniperConfig = global.botConfig.userConfig?.market?.sniper;
    
    if (!sniperConfig || !sniperConfig.enabled) {
      return;
    }
    
    // Filter listings based on sniper criteria
    const targetListings = listings.filter(listing => {
      // Check price limit
      if (sniperConfig.maxPrice && listing.price > sniperConfig.maxPrice) {
        return false;
      }
      
      // Check target Pokémon
      if (sniperConfig.targetPokemon && sniperConfig.targetPokemon.length > 0) {
        if (!sniperConfig.targetPokemon.some(target => 
          listing.name.toLowerCase().includes(target.toLowerCase()))) {
          return false;
        }
      }
      
      return true;
    });
    
    if (!targetListings.length) {
      logger.debug('No listings match sniper criteria');
      return;
    }
    
    // Sort by best value (lowest price)
    targetListings.sort((a, b) => a.price - b.price);
    
    // Get the best listing
    const bestListing = targetListings[0];
    
    logger.info(`Market sniper found target: ${bestListing.name} (Level ${bestListing.level}, ${bestListing.iv}% IV) for ${bestListing.price}`);
    
    // Add to market queue
    global.botConfig.marketQueue.push({
      action: 'buy',
      listingId: bestListing.id,
      channelId: channel.id,
      timestamp: Date.now()
    });
    
    // Process market queue
    processMarketQueue();
  } catch (error) {
    logger.error('Error processing market sniper:', error);
  }
}

// Process market flipper
async function processFlipper(channel, listings) {
  try {
    const flipperConfig = global.botConfig.userConfig?.market?.flipper;
    
    if (!flipperConfig || !flipperConfig.enabled) {
      return;
    }
    
    // This is a placeholder for the market flipper logic
    // In a real implementation, this would analyze market trends
    // and identify Pokémon to buy low and sell high
    
    logger.debug('Market flipper processing not fully implemented');
  } catch (error) {
    logger.error('Error processing market flipper:', error);
  }
}

// Process market swiper
async function processSwiper(channel, listings) {
  try {
    const swiperConfig = global.botConfig.userConfig?.market?.swiper;
    
    if (!swiperConfig || !swiperConfig.enabled) {
      return;
    }
    
    // This is a placeholder for the market swiper logic
    // In a real implementation, this would identify trash Pokémon
    // to list on the market at configured prices
    
    logger.debug('Market swiper processing not fully implemented');
  } catch (error) {
    logger.error('Error processing market swiper:', error);
  }
}

// Process market queue
async function processMarketQueue() {
  // Check if already processing
  if (global.processingMarketQueue) {
    return;
  }
  
  global.processingMarketQueue = true;
  
  try {
    while (global.botConfig.marketQueue.length > 0) {
      const marketItem = global.botConfig.marketQueue.shift();
      
      // Get channel
      const channel = await global.client.channels.fetch(marketItem.channelId);
      if (!channel) {
        logger.warn(`Channel ${marketItem.channelId} not found`);
        continue;
      }
      
      // Simulate human typing
      if (global.botConfig.userConfig?.antiDetection?.humanLikeTyping) {
        await simulateHumanTyping(channel);
      }
      
      // Execute market action
      if (marketItem.action === 'buy') {
        await buyMarketListing(channel, marketItem.listingId);
      } else if (marketItem.action === 'sell') {
        await sellPokemon(channel, marketItem.pokemonId, marketItem.price);
      }
      
      // Add delay between actions
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  } catch (error) {
    logger.error('Error processing market queue:', error);
  } finally {
    global.processingMarketQueue = false;
  }
}

// Buy market listing
async function buyMarketListing(channel, listingId) {
  try {
    // Send buy command
    const buyMessage = await channel.send(`${global.botConfig.prefix}market buy ${listingId}`);
    
    logger.info(`Sent market buy command for listing #${listingId}`);
    
    // Wait for Pokétwo's response
    const response = await waitForPokétwoResponse(channel, buyMessage.id);
    
    // Process the response
    if (response) {
      const success = response.content.toLowerCase().includes('you bought');
      
      if (success) {
        // Extract Pokémon info from response
        const pokemonInfo = extractPokemonInfoFromMarket(response);
        
        // Log to database if available
        if (models.MarketLog) {
          try {
            await models.MarketLog.create({
              userId: global.client.user.id,
              action: 'buy',
              pokemonName: pokemonInfo.name,
              price: pokemonInfo.price,
              level: pokemonInfo.level,
              iv: pokemonInfo.iv,
              shiny: pokemonInfo.shiny
            });
          } catch (dbError) {
            logger.error('Failed to log market transaction to database:', dbError);
          }
        }
        
        // Log to console/file
        logger.market('bought', pokemonInfo.name, pokemonInfo.price, {
          level: pokemonInfo.level,
          iv: pokemonInfo.iv,
          shiny: pokemonInfo.shiny
        });
      } else {
        logger.warn(`Failed to buy listing #${listingId}: ${response.content}`);
      }
      
      return success;
    }
    
    return false;
  } catch (error) {
    logger.error('Error buying market listing:', error);
    return false;
  }
}

// Sell Pokemon
async function sellPokemon(channel, pokemonId, price) {
  try {
    // Send sell command
    const sellMessage = await channel.send(`${global.botConfig.prefix}market sell ${pokemonId} ${price}`);
    
    logger.info(`Sent market sell command for Pokémon #${pokemonId} at price ${price}`);
    
    // Wait for Pokétwo's response
    const response = await waitForPokétwoResponse(channel, sellMessage.id);
    
    // Process the response
    if (response) {
      const success = response.content.toLowerCase().includes('listed');
      
      if (success) {
        // Extract Pokémon info from response
        const pokemonInfo = extractPokemonInfoFromMarket(response);
        
        // Log to database if available
        if (models.MarketLog) {
          try {
            await models.MarketLog.create({
              userId: global.client.user.id,
              action: 'sell',
              pokemonName: pokemonInfo.name,
              price: price,
              level: pokemonInfo.level,
              iv: pokemonInfo.iv,
              shiny: pokemonInfo.shiny
            });
          } catch (dbError) {
            logger.error('Failed to log market transaction to database:', dbError);
          }
        }
        
        // Log to console/file
        logger.market('listed', pokemonInfo.name, price, {
          level: pokemonInfo.level,
          iv: pokemonInfo.iv,
          shiny: pokemonInfo.shiny
        });
      } else {
        logger.warn(`Failed to sell Pokémon #${pokemonId}: ${response.content}`);
      }
      
      return success;
    }
    
    return false;
  } catch (error) {
    logger.error('Error selling Pokémon:', error);
    return false;
  }
}

// Wait for Pokétwo's response
async function waitForPokétwoResponse(channel, messageId) {
  return new Promise(resolve => {
    // Set up a message collector
    const filter = m => 
      m.author.id === '716390085896962058' && // Pokétwo bot ID
      m.reference?.messageId === messageId;
    
    const collector = channel.createMessageCollector({ filter, time: 10000, max: 1 });
    
    collector.on('collect', message => {
      resolve(message);
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        logger.warn('No response from Pokétwo');
        resolve(null);
      }
    });
  });
}

// Extract Pokemon info from market response
function extractPokemonInfoFromMarket(response) {
  const content = response.content;
  const info = {
    name: null,
    level: null,
    iv: null,
    price: null,
    shiny: false
  };
  
  // Extract name
  const nameMatch = content.match(/\*\*([^*]+)\*\*/);
  if (nameMatch && nameMatch[1]) {
    info.name = nameMatch[1].trim();
  }
  
  // Extract level
  const levelMatch = content.match(/Level (\d+)/i);
  if (levelMatch && levelMatch[1]) {
    info.level = parseInt(levelMatch[1], 10);
  }
  
  // Extract IV
  const ivMatch = content.match(/(\d+(\.\d+)?)%\s*IV/i);
  if (ivMatch && ivMatch[1]) {
    info.iv = parseFloat(ivMatch[1]);
  }
  
  // Extract price
  const priceMatch = content.match(/(\d+,?)+\s*credits/i);
  if (priceMatch && priceMatch[0]) {
    info.price = parseInt(priceMatch[0].replace(/[^0-9]/g, ''), 10);
  }
  
  // Check if shiny
  info.shiny = content.toLowerCase().includes('✨') || content.toLowerCase().includes('shiny');
  
  return info;
}

module.exports = {
  handleMarketListings,
  parseMarketListings
};