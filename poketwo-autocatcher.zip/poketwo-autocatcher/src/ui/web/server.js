const express = require('express');
const cors = require('cors');
const path = require('path');
const { logger } = require('../../modules/logger/logger');

// Create Express app
const app = express();
const port = process.env.WEB_PORT || 3000;

// Enable CORS
app.use(cors());

// Parse JSON bodies
app.use(express.json());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// API routes
const apiRouter = express.Router();

// Get bot status
apiRouter.get('/status', (req, res) => {
  try {
    const status = {
      version: global.botConfig.version,
      uptime: Date.now() - global.botConfig.startTime,
      enabledServers: Array.from(global.botConfig.enabledServers),
      catchQueue: global.botConfig.catchQueue.length,
      levelQueue: global.botConfig.levelQueue.length,
      marketQueue: global.botConfig.marketQueue.length,
      config: {
        autocatcher: {
          enabled: global.botConfig.userConfig?.autocatcher?.enabled || false,
          filters: global.botConfig.userConfig?.autocatcher?.filters?.enabled || false
        },
        autoleveler: {
          enabled: global.botConfig.userConfig?.autoleveler?.enabled || false,
          mode: global.botConfig.userConfig?.autoleveler?.mode || 'manual'
        },
        spawner: {
          enabled: global.botConfig.userConfig?.spawner?.enabled || false,
          mode: global.botConfig.userConfig?.spawner?.mode || 'normal'
        },
        market: {
          sniperEnabled: global.botConfig.userConfig?.market?.sniper?.enabled || false,
          flipperEnabled: global.botConfig.userConfig?.market?.flipper?.enabled || false,
          swiperEnabled: global.botConfig.userConfig?.market?.swiper?.enabled || false
        }
      }
    };
    
    res.json(status);
  } catch (error) {
    logger.error('Error getting bot status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get configuration
apiRouter.get('/config', (req, res) => {
  try {
    res.json(global.botConfig.userConfig || {});
  } catch (error) {
    logger.error('Error getting configuration:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update configuration
apiRouter.post('/config', (req, res) => {
  try {
    const { section, key, value } = req.body;
    
    if (!section) {
      return res.status(400).json({ error: 'Section is required' });
    }
    
    // Update config
    const { updateConfig } = require('../../core/config');
    
    updateConfig(section, key, value)
      .then(success => {
        if (success) {
          res.json({ success: true, message: 'Configuration updated successfully' });
        } else {
          res.status(500).json({ error: 'Failed to update configuration' });
        }
      })
      .catch(error => {
        logger.error('Error updating configuration:', error);
        res.status(500).json({ error: 'Internal server error' });
      });
  } catch (error) {
    logger.error('Error updating configuration:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get catch logs
apiRouter.get('/logs/catches', async (req, res) => {
  try {
    const { models } = require('../../core/database');
    
    if (!models.CatchLog) {
      return res.status(503).json({ error: 'Database not available' });
    }
    
    const limit = parseInt(req.query.limit) || 100;
    const skip = parseInt(req.query.skip) || 0;
    
    const logs = await models.CatchLog.find()
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(limit);
    
    const count = await models.CatchLog.countDocuments();
    
    res.json({
      logs,
      total: count,
      limit,
      skip
    });
  } catch (error) {
    logger.error('Error getting catch logs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get market logs
apiRouter.get('/logs/market', async (req, res) => {
  try {
    const { models } = require('../../core/database');
    
    if (!models.MarketLog) {
      return res.status(503).json({ error: 'Database not available' });
    }
    
    const limit = parseInt(req.query.limit) || 100;
    const skip = parseInt(req.query.skip) || 0;
    
    const logs = await models.MarketLog.find()
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(limit);
    
    const count = await models.MarketLog.countDocuments();
    
    res.json({
      logs,
      total: count,
      limit,
      skip
    });
  } catch (error) {
    logger.error('Error getting market logs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Control routes
apiRouter.post('/control/autocatcher', (req, res) => {
  try {
    const { enabled } = req.body;
    
    if (enabled === undefined) {
      return res.status(400).json({ error: 'Enabled status is required' });
    }
    
    // Update config
    const { updateConfig } = require('../../core/config');
    
    updateConfig('autocatcher', 'enabled', enabled)
      .then(success => {
        if (success) {
          res.json({ success: true, message: `AutoCatcher ${enabled ? 'enabled' : 'disabled'}` });
        } else {
          res.status(500).json({ error: 'Failed to update configuration' });
        }
      })
      .catch(error => {
        logger.error('Error updating AutoCatcher:', error);
        res.status(500).json({ error: 'Internal server error' });
      });
  } catch (error) {
    logger.error('Error controlling AutoCatcher:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

apiRouter.post('/control/autoleveler', (req, res) => {
  try {
    const { enabled } = req.body;
    
    if (enabled === undefined) {
      return res.status(400).json({ error: 'Enabled status is required' });
    }
    
    // Update config
    const { updateConfig } = require('../../core/config');
    
    updateConfig('autoleveler', 'enabled', enabled)
      .then(success => {
        if (success) {
          // Start or stop auto-leveler
          if (enabled) {
            const { startAutoLeveler } = require('../../modules/autoleveler/autoLeveler');
            startAutoLeveler();
          } else {
            const { stopAutoLeveler } = require('../../modules/autoleveler/autoLeveler');
            stopAutoLeveler();
          }
          
          res.json({ success: true, message: `AutoLeveler ${enabled ? 'enabled' : 'disabled'}` });
        } else {
          res.status(500).json({ error: 'Failed to update configuration' });
        }
      })
      .catch(error => {
        logger.error('Error updating AutoLeveler:', error);
        res.status(500).json({ error: 'Internal server error' });
      });
  } catch (error) {
    logger.error('Error controlling AutoLeveler:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

apiRouter.post('/control/spawner', (req, res) => {
  try {
    const { enabled, mode } = req.body;
    
    if (enabled === undefined) {
      return res.status(400).json({ error: 'Enabled status is required' });
    }
    
    // Update config
    const { updateConfig } = require('../../core/config');
    
    // Update enabled status
    updateConfig('spawner', 'enabled', enabled)
      .then(async success => {
        if (success) {
          // Update mode if provided
          if (mode) {
            await updateConfig('spawner', 'mode', mode);
          }
          
          // Start or stop spawner
          if (enabled) {
            const { startSpawner } = require('../../modules/autoleveler/spawner');
            startSpawner();
          } else {
            const { stopSpawner } = require('../../modules/autoleveler/spawner');
            stopSpawner();
          }
          
          res.json({ 
            success: true, 
            message: `Spawner ${enabled ? 'enabled' : 'disabled'}${mode ? ` in ${mode} mode` : ''}` 
          });
        } else {
          res.status(500).json({ error: 'Failed to update configuration' });
        }
      })
      .catch(error => {
        logger.error('Error updating Spawner:', error);
        res.status(500).json({ error: 'Internal server error' });
      });
  } catch (error) {
    logger.error('Error controlling Spawner:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

apiRouter.post('/control/market', (req, res) => {
  try {
    const { feature, enabled } = req.body;
    
    if (!feature || enabled === undefined) {
      return res.status(400).json({ error: 'Feature and enabled status are required' });
    }
    
    if (!['sniper', 'flipper', 'swiper'].includes(feature)) {
      return res.status(400).json({ error: 'Invalid feature' });
    }
    
    // Update config
    const { updateConfig } = require('../../core/config');
    
    updateConfig('market', `${feature}.enabled`, enabled)
      .then(success => {
        if (success) {
          res.json({ success: true, message: `Market ${feature} ${enabled ? 'enabled' : 'disabled'}` });
        } else {
          res.status(500).json({ error: 'Failed to update configuration' });
        }
      })
      .catch(error => {
        logger.error(`Error updating Market ${feature}:`, error);
        res.status(500).json({ error: 'Internal server error' });
      });
  } catch (error) {
    logger.error('Error controlling Market feature:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Mount API router
app.use('/api', apiRouter);

// Catch-all route to serve the SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start web server
function startWebServer() {
  return new Promise((resolve, reject) => {
    try {
      const server = app.listen(port, '0.0.0.0', () => {
        logger.success(`Web dashboard running at http://localhost:${port}`);
        resolve(server);
      });
      
      server.on('error', (error) => {
        logger.error('Web server error:', error);
        reject(error);
      });
    } catch (error) {
      logger.error('Failed to start web server:', error);
      reject(error);
    }
  });
}

module.exports = {
  startWebServer,
  app
};