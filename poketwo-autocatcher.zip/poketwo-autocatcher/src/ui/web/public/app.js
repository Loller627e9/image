// DOM Elements
const pageTitle = document.getElementById('page-title');
const navLinks = document.querySelectorAll('.nav-link');
const contentSections = document.querySelectorAll('.content-section');
const refreshBtn = document.getElementById('refresh-btn');

// Status elements
const versionElement = document.getElementById('version');
const botStatusElement = document.getElementById('bot-status');
const uptimeElement = document.getElementById('uptime');
const enabledServersElement = document.getElementById('enabled-servers');
const catchQueueElement = document.getElementById('catch-queue');
const levelQueueElement = document.getElementById('level-queue');
const filtersStatusElement = document.getElementById('filters-status');
const sniperStatusElement = document.getElementById('sniper-status');
const flipperStatusElement = document.getElementById('flipper-status');
const swiperStatusElement = document.getElementById('swiper-status');
const recentCatchesElement = document.getElementById('recent-catches');

// Toggle elements
const autocatcherToggle = document.getElementById('autocatcher-toggle');
const autolevelerToggle = document.getElementById('autoleveler-toggle');
const spawnerToggle = document.getElementById('spawner-toggle');
const spawnerModeSelect = document.getElementById('spawner-mode');

// API base URL
const API_BASE_URL = '/api';

// Initialize the dashboard
async function initDashboard() {
  // Set up navigation
  setupNavigation();
  
  // Load initial data
  await refreshDashboard();
  
  // Set up event listeners
  setupEventListeners();
  
  // Set up refresh interval
  setInterval(refreshDashboard, 30000); // Refresh every 30 seconds
}

// Set up navigation
function setupNavigation() {
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Get the section ID from the href
      const sectionId = link.getAttribute('href').substring(1);
      
      // Update active link
      navLinks.forEach(navLink => navLink.classList.remove('active'));
      link.classList.add('active');
      
      // Update page title
      pageTitle.textContent = link.textContent.trim();
      
      // Show the selected section
      contentSections.forEach(section => {
        if (section.id === `${sectionId}-section`) {
          section.classList.remove('d-none');
        } else {
          section.classList.add('d-none');
        }
      });
    });
  });
}

// Set up event listeners
function setupEventListeners() {
  // Refresh button
  refreshBtn.addEventListener('click', refreshDashboard);
  
  // AutoCatcher toggle
  autocatcherToggle.addEventListener('change', async () => {
    await toggleFeature('autocatcher', autocatcherToggle.checked);
  });
  
  // Auto-Leveler toggle
  autolevelerToggle.addEventListener('change', async () => {
    await toggleFeature('autoleveler', autolevelerToggle.checked);
  });
  
  // Spawner toggle
  spawnerToggle.addEventListener('change', async () => {
    await toggleFeature('spawner', spawnerToggle.checked);
  });
  
  // Spawner mode select
  spawnerModeSelect.addEventListener('change', async () => {
    await updateSpawnerMode(spawnerModeSelect.value);
  });
}

// Refresh dashboard data
async function refreshDashboard() {
  try {
    // Show loading indicator
    refreshBtn.innerHTML = '<span class="loading me-2"></span> Refreshing';
    refreshBtn.disabled = true;
    
    // Fetch bot status
    const status = await fetchBotStatus();
    
    // Update UI with status data
    updateStatusUI(status);
    
    // Fetch recent catches
    const catches = await fetchRecentCatches();
    
    // Update recent catches UI
    updateRecentCatchesUI(catches);
    
    // Hide loading indicator
    refreshBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh';
    refreshBtn.disabled = false;
  } catch (error) {
    console.error('Error refreshing dashboard:', error);
    
    // Hide loading indicator
    refreshBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh';
    refreshBtn.disabled = false;
    
    // Show error notification
    showNotification('Error refreshing dashboard', 'danger');
  }
}

// Fetch bot status from API
async function fetchBotStatus() {
  const response = await fetch(`${API_BASE_URL}/status`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch bot status: ${response.statusText}`);
  }
  
  return await response.json();
}

// Fetch recent catches from API
async function fetchRecentCatches() {
  const response = await fetch(`${API_BASE_URL}/logs/catches?limit=5`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch recent catches: ${response.statusText}`);
  }
  
  return await response.json();
}

// Update UI with status data
function updateStatusUI(status) {
  // Update version
  versionElement.textContent = `v${status.version}`;
  
  // Update uptime
  const uptime = formatUptime(status.uptime);
  uptimeElement.textContent = uptime;
  
  // Update enabled servers
  enabledServersElement.textContent = status.enabledServers.length;
  
  // Update queue counts
  catchQueueElement.textContent = status.catchQueue;
  levelQueueElement.textContent = status.levelQueue;
  
  // Update feature statuses
  updateFeatureStatus(filtersStatusElement, status.config.autocatcher.filters);
  updateFeatureStatus(sniperStatusElement, status.config.market.sniperEnabled);
  updateFeatureStatus(flipperStatusElement, status.config.market.flipperEnabled);
  updateFeatureStatus(swiperStatusElement, status.config.market.swiperEnabled);
  
  // Update toggles
  autocatcherToggle.checked = status.config.autocatcher.enabled;
  autolevelerToggle.checked = status.config.autoleveler.enabled;
  spawnerToggle.checked = status.config.spawner.enabled;
  
  // Update spawner mode
  spawnerModeSelect.value = status.config.spawner.mode;
}

// Update recent catches UI
function updateRecentCatchesUI(catchData) {
  if (!catchData.logs || catchData.logs.length === 0) {
    recentCatchesElement.innerHTML = '<tr><td colspan="4" class="text-center">No recent catches</td></tr>';
    return;
  }
  
  let html = '';
  
  catchData.logs.forEach(log => {
    const date = new Date(log.timestamp);
    const formattedTime = date.toLocaleTimeString();
    
    html += `
      <tr>
        <td>${log.pokemonName}${log.shiny ? ' ✨' : ''}</td>
        <td>${log.level || 'N/A'}</td>
        <td>${log.iv ? log.iv + '%' : 'N/A'}</td>
        <td>${formattedTime}</td>
      </tr>
    `;
  });
  
  recentCatchesElement.innerHTML = html;
}

// Update feature status badge
function updateFeatureStatus(element, enabled) {
  if (enabled) {
    element.textContent = 'Enabled';
    element.classList.remove('bg-secondary');
    element.classList.add('bg-success');
  } else {
    element.textContent = 'Disabled';
    element.classList.remove('bg-success');
    element.classList.add('bg-secondary');
  }
}

// Format uptime
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  return `${days}d ${hours % 24}h ${minutes % 60}m ${seconds % 60}s`;
}

// Toggle feature
async function toggleFeature(feature, enabled) {
  try {
    let endpoint = '';
    let data = {};
    
    if (feature === 'autocatcher') {
      endpoint = '/control/autocatcher';
      data = { enabled };
    } else if (feature === 'autoleveler') {
      endpoint = '/control/autoleveler';
      data = { enabled };
    } else if (feature === 'spawner') {
      endpoint = '/control/spawner';
      data = { enabled, mode: spawnerModeSelect.value };
    } else if (feature.startsWith('market-')) {
      const marketFeature = feature.substring(7); // Remove 'market-' prefix
      endpoint = '/control/market';
      data = { feature: marketFeature, enabled };
    }
    
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      throw new Error(`Failed to toggle ${feature}: ${response.statusText}`);
    }
    
    const result = await response.json();
    
    // Show success notification
    showNotification(result.message, 'success');
    
    // Refresh dashboard
    await refreshDashboard();
  } catch (error) {
    console.error(`Error toggling ${feature}:`, error);
    
    // Show error notification
    showNotification(`Error toggling ${feature}`, 'danger');
    
    // Refresh dashboard to reset UI
    await refreshDashboard();
  }
}

// Update spawner mode
async function updateSpawnerMode(mode) {
  try {
    const response = await fetch(`${API_BASE_URL}/control/spawner`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        enabled: spawnerToggle.checked,
        mode
      })
    });
    
    if (!response.ok) {
      throw new Error(`Failed to update spawner mode: ${response.statusText}`);
    }
    
    const result = await response.json();
    
    // Show success notification
    showNotification(result.message, 'success');
  } catch (error) {
    console.error('Error updating spawner mode:', error);
    
    // Show error notification
    showNotification('Error updating spawner mode', 'danger');
    
    // Refresh dashboard to reset UI
    await refreshDashboard();
  }
}

// Show notification
function showNotification(message, type) {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `toast align-items-center text-white bg-${type} border-0`;
  notification.setAttribute('role', 'alert');
  notification.setAttribute('aria-live', 'assertive');
  notification.setAttribute('aria-atomic', 'true');
  
  notification.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        ${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  `;
  
  // Create toast container if it doesn't exist
  let toastContainer = document.querySelector('.toast-container');
  
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    document.body.appendChild(toastContainer);
  }
  
  // Add notification to container
  toastContainer.appendChild(notification);
  
  // Initialize Bootstrap toast
  const toast = new bootstrap.Toast(notification, {
    autohide: true,
    delay: 5000
  });
  
  // Show toast
  toast.show();
  
  // Remove from DOM after hidden
  notification.addEventListener('hidden.bs.toast', () => {
    notification.remove();
  });
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', initDashboard);