# Olympus Bot Enhanced

An advanced Discord bot with powerful moderation and community features.

## Features

- **Antinuke System**: Protection against mass bans, role deletions, and channel wipes
- **Automod System**: Smart content filtering and spam protection
- **Custom Roles**: Easy role management with slash commands
- **Scheduled Messages**: Automated announcements
- **Birthday System**: Automated birthday celebrations
- **Poll System**: Interactive polls with real-time voting
- **Warning System**: Progressive moderation system
- **Economy System**: Server currency and rewards
- **Smart Cooldowns**: Rate limiting for commands

## Bot Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create a `.env` file with your bot token:
   ```
   DISCORD_TOKEN=your_bot_token_here
   ```
4. Update the bot.py file with your application ID
5. Run the bot:
   ```bash
   python bot.py
   ```

## Website Setup

1. Install Node.js dependencies:
   ```bash
   npm install
   ```
2. Start the development server:
   ```bash
   npm run dev
   ```
3. Build for production:
   ```bash
   npm run build
   ```
4. Preview production build:
   ```bash
   npm run preview
   ```

The website will be available at `http://localhost:5173` during development.

## Commands

### Moderation
- `/warn <user> <reason>` - Warn a user
- `/role <role>` - Assign/remove a role

### Utility
- `/schedule <channel> <time> <message>` - Schedule a message
- `/poll <question> <options>` - Create a poll
- `/setbirthday <date>` - Set your birthday

### Economy
- `/balance` - Check your balance
- `/daily` - Claim daily coins

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a pull request

## License

MIT License

## Support

For support, join our [Discord server](https://discord.gg/your-invite-link)