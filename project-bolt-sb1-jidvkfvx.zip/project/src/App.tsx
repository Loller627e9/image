import React from 'react';
import { Shield, MessageSquare, Bot, Calendar, Gift, PieChart, AlertTriangle, Coins, Clock, Music, Gamepad, Mic, UserPlus, FileText, Smile, Video, Crown, Settings, Zap, Command, Radio, Sparkles, Star, Rocket } from 'lucide-react';

function ModuleCard({ icon: Icon, title }: { icon: React.ElementType, title: string }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-[#5865F2]/10 transition-colors cursor-pointer group">
      <Icon className="w-5 h-5 text-[#5865F2] group-hover:text-[#7984F5] transition-colors" strokeWidth={2.5} />
      <span className="text-gray-200 group-hover:text-white transition-colors">{title}</span>
    </div>
  );
}

function App() {
  const mainModules = [
    { icon: Shield, title: "Antinuke" },
    { icon: Command, title: "Automod" },
    { icon: Zap, title: "Server" },
    { icon: Star, title: "Utility" },
    { icon: AlertTriangle, title: "Moderation" },
    { icon: Sparkles, title: "General" },
    { icon: Radio, title: "Music" },
    { icon: Gift, title: "Giveaway" },
    { icon: Rocket, title: "Ai Utils" }
  ];

  const extraModules = [
    { icon: Smile, title: "Fun" },
    { icon: MessageSquare, title: "Ignore" },
    { icon: Video, title: "Media" },
    { icon: Gamepad, title: "Games" },
    { icon: Crown, title: "Vanityroles" },
    { icon: Crown, title: "Vcroles" },
    { icon: Mic, title: "Voice" },
    { icon: UserPlus, title: "Welcomer" },
    { icon: FileText, title: "Logging" }
  ];

  return (
    <div className="min-h-screen bg-[#313338] text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto bg-[#2B2D31] rounded-lg shadow-xl p-6">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-[#5865F2] rounded-full flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Elevate Your Discord</h1>
              <p className="text-[#B5BAC1]">Experience with Fizer</p>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[#B5BAC1]">Server Prefix:</span>
              <span className="text-white">,</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[#B5BAC1]">Total Commands:</span>
              <span className="text-white">427</span>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-[#B5BAC1] font-semibold mb-2">📁 Modules:</h2>
              <div className="space-y-1">
                {mainModules.map((module, index) => (
                  <ModuleCard key={index} icon={module.icon} title={module.title} />
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-[#B5BAC1] font-semibold mb-2">📁 Extra Modules:</h2>
              <div className="space-y-1">
                {extraModules.map((module, index) => (
                  <ModuleCard key={index} icon={module.icon} title={module.title} />
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#3F4147]">
              <h2 className="text-[#B5BAC1] font-semibold mb-2">🔗 Links</h2>
              <div className="flex gap-4">
                <a href="#" className="text-[#00A8FC] hover:underline">Invite Fizer</a>
                <span className="text-[#B5BAC1]">|</span>
                <a href="#" className="text-[#00A8FC] hover:underline">Support</a>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-[#3F4147]">
            <div className="h-12 bg-[#5865F2] rounded-lg flex items-center justify-center">
              <span className="text-white font-bold tracking-wider">FIZER</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;