import discord
from discord.ext import commands
import datetime
import json
import asyncio
from typing import Optional
import sqlite3
from discord import app_commands

class OlympusBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=",",  # Changed to match the interface
            intents=discord.Intents.all(),
            application_id="YOUR_APPLICATION_ID"
        )
        self.cooldowns = commands.CooldownMapping.from_cooldown(
            1, 60, commands.BucketType.user
        )
        
        # Initialize database
        self.db = sqlite3.connect('olympus.db')
        self.cursor = self.db.cursor()
        self.setup_database()

    async def setup_hook(self):
        await self.tree.sync()
        
    def setup_database(self):
        # Create necessary tables
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS economy (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER DEFAULT 0,
                last_daily TIMESTAMP
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS warnings (
                user_id INTEGER,
                guild_id INTEGER,
                reason TEXT,
                timestamp TIMESTAMP,
                moderator_id INTEGER
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS birthdays (
                user_id INTEGER PRIMARY KEY,
                birthday DATE,
                guild_id INTEGER
            )
        ''')
        
        self.db.commit()

bot = OlympusBot()

@bot.tree.command(name="help", description="Show bot modules and commands")
async def help(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Elevate Your Discord Experience with Fizer",
        description="Best Quality Security and Versatility!",
        color=0x5865F2  # Discord Blurple color
    )
    
    # Add bot info
    embed.add_field(
        name="Bot Information",
        value=f"🤖 Server Prefix: ,\n📊 Total Commands: 427",
        inline=False
    )
    
    # Main Modules
    modules = (
        "🛡️ Antinuke\n"
        "🔍 Automod\n"
        "⚡ Server\n"
        "🔧 Utility\n"
        "⚠️ Moderation\n"
        "✨ General\n"
        "🎵 Music\n"
        "🎁 Giveaway\n"
        "🤖 Ai Utils"
    )
    embed.add_field(name="📁 Modules", value=modules, inline=True)
    
    # Extra Modules
    extra_modules = (
        "😄 Fun\n"
        "💬 Ignore\n"
        "🎥 Media\n"
        "🎮 Games\n"
        "👑 Vanityroles\n"
        "🎭 Vcroles\n"
        "🎤 Voice\n"
        "👋 Welcomer\n"
        "📝 Logging"
    )
    embed.add_field(name="📁 Extra Modules", value=extra_modules, inline=True)
    
    # Add links
    embed.add_field(
        name="🔗 Links",
        value="[Invite Fizer](https://discord.com/api/oauth2/authorize) | [Support](https://discord.gg/your-server)",
        inline=False
    )
    
    # Set footer
    embed.set_footer(text="FIZER", icon_url=bot.user.avatar.url if bot.user.avatar else None)
    
    await interaction.response.send_message(embed=embed)

# Antinuke System
@bot.event
async def on_guild_channel_delete(channel):
    async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
        if entry.user.id != bot.user.id:
            # Alert admins
            admin_channel = discord.utils.get(channel.guild.channels, name="admin-logs")
            if admin_channel:
                await admin_channel.send(f"⚠️ Channel deletion detected! Channel: {channel.name}, By: {entry.user.mention}")

# Automod System
@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Basic word filter
    banned_words = ["badword1", "badword2"]  # Add your banned words
    if any(word in message.content.lower() for word in banned_words):
        await message.delete()
        await message.channel.send(f"{message.author.mention} Message contained banned words!")
        return

    await bot.process_commands(message)

# Custom Roles
@bot.tree.command(name="role", description="Assign or remove a role")
@app_commands.describe(role="The role to assign/remove")
async def role(interaction: discord.Interaction, role: discord.Role):
    if role in interaction.user.roles:
        await interaction.user.remove_roles(role)
        await interaction.response.send_message(f"Removed role: {role.name}", ephemeral=True)
    else:
        await interaction.user.add_roles(role)
        await interaction.response.send_message(f"Added role: {role.name}", ephemeral=True)

# Scheduled Messages
@bot.tree.command(name="schedule", description="Schedule a message")
@app_commands.describe(
    channel="The channel to send the message in",
    time="Time in minutes from now",
    message="The message to send"
)
async def schedule(interaction: discord.Interaction, channel: discord.TextChannel, time: int, message: str):
    await interaction.response.send_message(f"Message scheduled for {time} minutes from now in {channel.mention}")
    await asyncio.sleep(time * 60)
    await channel.send(message)

# Birthday System
@bot.tree.command(name="setbirthday", description="Set your birthday")
@app_commands.describe(date="Your birthday (YYYY-MM-DD)")
async def setbirthday(interaction: discord.Interaction, date: str):
    try:
        birthday = datetime.datetime.strptime(date, "%Y-%m-%d").date()
        bot.cursor.execute(
            "INSERT OR REPLACE INTO birthdays (user_id, birthday, guild_id) VALUES (?, ?, ?)",
            (interaction.user.id, birthday, interaction.guild_id)
        )
        bot.db.commit()
        await interaction.response.send_message("Birthday set successfully!", ephemeral=True)
    except ValueError:
        await interaction.response.send_message("Invalid date format! Use YYYY-MM-DD", ephemeral=True)

# Poll System
@bot.tree.command(name="poll", description="Create a poll")
@app_commands.describe(
    question="The poll question",
    options="Options separated by comma"
)
async def poll(interaction: discord.Interaction, question: str, options: str):
    options_list = options.split(",")
    if len(options_list) > 9:
        await interaction.response.send_message("Maximum 9 options allowed!", ephemeral=True)
        return

    emoji_numbers = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"]
    description = "\n".join(f"{emoji_numbers[i]} {option.strip()}" for i, option in enumerate(options_list))
    
    embed = discord.Embed(title=question, description=description, color=discord.Color.blue())
    poll_message = await interaction.channel.send(embed=embed)
    
    for i in range(len(options_list)):
        await poll_message.add_reaction(emoji_numbers[i])
    
    await interaction.response.send_message("Poll created!", ephemeral=True)

# Warning System
@bot.tree.command(name="warn", description="Warn a user")
@app_commands.describe(
    user="The user to warn",
    reason="Reason for the warning"
)
async def warn(interaction: discord.Interaction, user: discord.Member, reason: str):
    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message("You don't have permission to warn users!", ephemeral=True)
        return

    bot.cursor.execute(
        "INSERT INTO warnings (user_id, guild_id, reason, timestamp, moderator_id) VALUES (?, ?, ?, ?, ?)",
        (user.id, interaction.guild_id, reason, datetime.datetime.now(), interaction.user.id)
    )
    bot.db.commit()

    # Check warning count
    bot.cursor.execute(
        "SELECT COUNT(*) FROM warnings WHERE user_id = ? AND guild_id = ?",
        (user.id, interaction.guild_id)
    )
    warning_count = bot.cursor.fetchone()[0]

    await interaction.response.send_message(f"Warned {user.mention} for: {reason}\nTotal warnings: {warning_count}")

    if warning_count >= 3:
        await user.timeout(datetime.timedelta(hours=1), reason="Exceeded warning threshold")

# Economy System
@bot.tree.command(name="balance", description="Check your balance")
async def balance(interaction: discord.Interaction):
    bot.cursor.execute("SELECT balance FROM economy WHERE user_id = ?", (interaction.user.id,))
    result = bot.cursor.fetchone()
    
    if result is None:
        bot.cursor.execute("INSERT INTO economy (user_id, balance) VALUES (?, ?)", (interaction.user.id, 0))
        bot.db.commit()
        balance = 0
    else:
        balance = result[0]
    
    await interaction.response.send_message(f"Your balance: {balance} coins", ephemeral=True)

@bot.tree.command(name="daily", description="Claim daily coins")
async def daily(interaction: discord.Interaction):
    bot.cursor.execute("SELECT last_daily FROM economy WHERE user_id = ?", (interaction.user.id,))
    result = bot.cursor.fetchone()
    
    if result is None:
        can_claim = True
    else:
        last_claim = result[0]
        if last_claim is None:
            can_claim = True
        else:
            time_since_claim = datetime.datetime.now() - datetime.datetime.fromisoformat(last_claim)
            can_claim = time_since_claim.days >= 1

    if can_claim:
        coins = 100
        bot.cursor.execute(
            "INSERT OR REPLACE INTO economy (user_id, balance, last_daily) VALUES (?, COALESCE((SELECT balance + ? FROM economy WHERE user_id = ?), ?), ?)",
            (interaction.user.id, coins, interaction.user.id, coins, datetime.datetime.now().isoformat())
        )
        bot.db.commit()
        await interaction.response.send_message(f"Claimed {coins} daily coins!", ephemeral=True)
    else:
        await interaction.response.send_message("You've already claimed your daily coins!", ephemeral=True)

bot.run('YOUR_BOT_TOKEN')